#!/usr/bin/env bun
/**
 * pollinations_cost_verifier.ts
 * 
 * Vérification précise des coûts avec attente suffisante
 * et analyse détaillée de l'usage
 */

const API_KEY = "sk_iUdeP1sX21yJjGfuH6fHBPQN1nk1Mf1q";
const BASE_URL = "https://gen.pollinations.ai";

const H: HeadersInit = {
  "Authorization": `Bearer ${API_KEY}`,
  "Content-Type": "application/json"
};

async function get<T>(url: string): Promise<T> {
  const r = await fetch(url, { headers: H });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}

async function getLastUsageEntries(count: number = 5): Promise<any[]> {
  const usage = await get<any>(`${BASE_URL}/account/usage?limit=${count}`);
  return usage.usage || [];
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function main() {
  console.log("=".repeat(90));
  console.log("🔍 VÉRIFICATION PRÉCISE DES COÛTS");
  console.log("=".repeat(90));
  
  // Voir les dernières entrées d'usage pour comprendre la structure
  console.log("\n📊 10 Dernières entrées d'usage:\n");
  
  const lastEntries = await getLastUsageEntries(10);
  
  for (let i = 0; i < lastEntries.length; i++) {
    const e = lastEntries[i];
    console.log(`--- Entry ${i + 1} ---`);
    console.log(`  Timestamp: ${e.timestamp}`);
    console.log(`  Model: ${e.model}`);
    console.log(`  Type: ${e.type}`);
    console.log(`  Cost USD: ${e.cost_usd}`);
    console.log(`  Input text: ${e.input_text_tokens || 0}`);
    console.log(`  Input image: ${e.input_image_tokens || 0}`);
    console.log(`  Output text: ${e.output_text_tokens || 0}`);
    console.log(`  Output image: ${e.output_image_tokens || 0}`);
    console.log(`  Output audio: ${e.output_audio_tokens || 0}`);
    console.log(`  Output video: ${e.output_video_seconds || 0}s`);
  }
  
  // Faire un test précis avec mesure
  console.log("\n\n" + "=".repeat(90));
  console.log("🧪 TEST PRÉCIS - IMAGE FLUX");
  console.log("=".repeat(90));
  
  const balanceBefore = await get<any>(`${BASE_URL}/account/balance`);
  console.log(`Balance avant: ${balanceBefore.balance}`);
  
  console.log("\nGénération d'image flux...");
  const startTime = Date.now();
  
  const r = await fetch(`${BASE_URL}/image/a%20red%20circle?model=flux&width=256&height=256`, {
    headers: H
  });
  
  const buffer = await r.arrayBuffer();
  const elapsed = Date.now() - startTime;
  
  console.log(`Image générée en ${elapsed}ms, taille: ${buffer.byteLength} bytes`);
  
  // Attendre que le coût soit enregistré
  console.log("\nAttente de 3 secondes pour la mise à jour...");
  await sleep(3000);
  
  // Vérifier le nouveau solde
  const balanceAfter = await get<any>(`${BASE_URL}/account/balance`);
  console.log(`Balance après: ${balanceAfter.balance}`);
  console.log(`Différence: ${balanceBefore.balance - balanceAfter.balance} pollen`);
  
  // Vérifier l'entrée d'usage
  await sleep(1000);
  const newEntries = await getLastUsageEntries(2);
  console.log("\nNouvelle entrée usage:");
  console.log(JSON.stringify(newEntries[0], null, 2));
  
  // Test AUDIO
  console.log("\n\n" + "=".repeat(90));
  console.log("🧪 TEST PRÉCIS - AUDIO TTS");
  console.log("=".repeat(90));
  
  const balanceBefore2 = await get<any>(`${BASE_URL}/account/balance`);
  console.log(`Balance avant: ${balanceBefore2.balance}`);
  
  console.log("\nGénération audio...");
  const startTime2 = Date.now();
  
  const r2 = await fetch(`${BASE_URL}/v1/audio/speech`, {
    method: "POST",
    headers: H,
    body: JSON.stringify({
      model: "elevenlabs",
      input: "Hello world, this is a test",
      voice: "alloy"
    })
  });
  
  const buffer2 = await r2.arrayBuffer();
  const elapsed2 = Date.now() - startTime2;
  
  console.log(`Audio généré en ${elapsed2}ms, taille: ${buffer2.byteLength} bytes`);
  
  console.log("\nAttente de 3 secondes...");
  await sleep(3000);
  
  const balanceAfter2 = await get<any>(`${BASE_URL}/account/balance`);
  console.log(`Balance après: ${balanceAfter2.balance}`);
  console.log(`Différence: ${balanceBefore2.balance - balanceAfter2.balance} pollen`);
  
  await sleep(1000);
  const newEntries2 = await getLastUsageEntries(2);
  console.log("\nNouvelle entrée usage:");
  console.log(JSON.stringify(newEntries2[0], null, 2));
  
  // Test TEXT
  console.log("\n\n" + "=".repeat(90));
  console.log("🧪 TEST PRÉCIS - TEXT OPENAI");
  console.log("=".repeat(90));
  
  const balanceBefore3 = await get<any>(`${BASE_URL}/account/balance`);
  console.log(`Balance avant: ${balanceBefore3.balance}`);
  
  console.log("\nGénération texte...");
  const startTime3 = Date.now();
  
  const r3 = await fetch(`${BASE_URL}/v1/chat/completions`, {
    method: "POST",
    headers: H,
    body: JSON.stringify({
      model: "openai",
      messages: [{ role: "user", content: "Say hello in one sentence." }],
      max_tokens: 50
    })
  });
  
  const data3 = await r3.json();
  const elapsed3 = Date.now() - startTime3;
  
  console.log(`Texte généré en ${elapsed3}ms`);
  console.log(`Tokens: ${data3.usage?.prompt_tokens}+${data3.usage?.completion_tokens}`);
  console.log(`Response: ${data3.choices?.[0]?.message?.content?.substring(0, 100)}...`);
  
  console.log("\nAttente de 3 secondes...");
  await sleep(3000);
  
  const balanceAfter3 = await get<any>(`${BASE_URL}/account/balance`);
  console.log(`Balance après: ${balanceAfter3.balance}`);
  console.log(`Différence: ${balanceBefore3.balance - balanceAfter3.balance} pollen`);
  
  await sleep(1000);
  const newEntries3 = await getLastUsageEntries(2);
  console.log("\nNouvelle entrée usage:");
  console.log(JSON.stringify(newEntries3[0], null, 2));
  
  // ============================================================
  // RÉSUMÉ
  // ============================================================
  console.log("\n\n" + "=".repeat(90));
  console.log("📊 RÉSUMÉ DES COÛTS RÉELS");
  console.log("=".repeat(90));
  
  const finalBalance = await get<any>(`${BASE_URL}/account/balance`);
  console.log(`\nBalance finale: ${finalBalance.balance}`);
  
  console.log("\n📊 Dernières entrées d'usage:\n");
  const finalEntries = await getLastUsageEntries(10);
  
  console.log("Timestamp           | Model           | Type            | Cost      | In Text | Out Text | Out Media");
  console.log("-".repeat(100));
  
  for (const e of finalEntries) {
    const outMedia = e.output_image_tokens || e.output_audio_tokens || e.output_video_seconds || 0;
    const mediaType = e.output_image_tokens ? "img" : (e.output_audio_tokens ? "audio" : (e.output_video_seconds ? "video" : "-"));
    console.log(
      `${e.timestamp?.substring(11, 19) || 'N/A'.padEnd(19)} | ` +
      `${(e.model || 'unknown').substring(0, 15).padEnd(15)} | ` +
      `${(e.type || 'unknown').padEnd(15)} | ` +
      `${(e.cost_usd || 0).toFixed(6).padStart(8)} | ` +
      `${(e.input_text_tokens || 0).toString().padStart(7)} | ` +
      `${(e.output_text_tokens || 0).toString().padStart(8)} | ` +
      `${outMedia} ${mediaType}`
    );
  }
}

main().catch(console.error);
