#!/usr/bin/env bun
/**
 * pollinations_benchmark.ts
 * 
 * Benchmark complet de tous les modèles avec:
 * - Vraies requêtes avec vraies réponses
 * - Mesure du temps de réponse
 * - Taille des réponses (texte, image, audio)
 * - Coût réel via /account/usage
 */

const API_KEY = "sk_iUdeP1sX21yJjGfuH6fHBPQN1nk1Mf1q";
const BASE_URL = "https://gen.pollinations.ai";

const H: HeadersInit = {
  "Authorization": `Bearer ${API_KEY}`,
  "Content-Type": "application/json"
};

// ============================================================
// TYPES
// ============================================================

interface BenchmarkResult {
  category: string;
  model: string;
  method: string;
  success: boolean;
  responseTimeMs: number;
  inputTokens?: number;
  outputTokens?: number;
  outputReasoningTokens?: number;
  outputImageTokens?: number;
  outputAudioTokens?: number;
  imageSize?: number;
  audioSize?: number;
  costPollen: number;
  error?: string;
}

const results: BenchmarkResult[] = [];

// ============================================================
// API HELPERS
// ============================================================

async function get<T>(url: string): Promise<T> {
  const r = await fetch(url, { headers: H });
  if (!r.ok) {
    const text = await r.text();
    throw new Error(`HTTP ${r.status}: ${text}`);
  }
  return r.json();
}

async function getLastUsage(): Promise<any> {
  const usage = await get<any>(`${BASE_URL}/account/usage?limit=1`);
  return usage.usage?.[0];
}

async function getBalance(): Promise<number> {
  const data = await get<{ balance: number }>(`${BASE_URL}/account/balance`);
  return data.balance;
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ============================================================
// BENCHMARK FUNCTIONS
// ============================================================

async function benchmarkText(model: string, prompt: string, maxTokens: number = 300): Promise<BenchmarkResult> {
  console.log(`  Testing ${model}...`);
  
  const startTime = Date.now();
  let success = false;
  let error: string | undefined;
  let inputTokens = 0;
  let outputTokens = 0;
  let outputReasoningTokens = 0;
  let responsePreview = "";
  
  try {
    const r = await fetch(`${BASE_URL}/v1/chat/completions`, {
      method: "POST",
      headers: H,
      body: JSON.stringify({
        model,
        messages: [{ role: "user", content: prompt }],
        max_tokens: maxTokens
      })
    });
    
    const data = await r.json();
    success = r.ok;
    
    if (r.ok) {
      inputTokens = data.usage?.prompt_tokens || 0;
      outputTokens = data.usage?.completion_tokens || 0;
      outputReasoningTokens = data.usage?.completion_tokens_details?.reasoning_tokens || 0;
      responsePreview = data.choices?.[0]?.message?.content?.substring(0, 80) || "";
    } else {
      error = data.error?.message || JSON.stringify(data);
    }
  } catch (e: any) {
    error = e.message;
    success = false;
  }
  
  const responseTimeMs = Date.now() - startTime;
  
  // Attendre que l'usage soit enregistré (au moins 1 seconde)
  await sleep(1500);
  
  // Récupérer le coût réel
  const lastUsage = await getLastUsage();
  const costPollen = lastUsage?.cost_usd || 0;
  
  console.log(`    ✅ ${responseTimeMs}ms | ${inputTokens}+${outputTokens} tokens | ${costPollen.toFixed(6)} pollen`);
  if (responsePreview) {
    console.log(`    Preview: "${responsePreview}..."`);
  }
  
  return {
    category: "TEXT",
    model,
    method: "POST /v1/chat/completions",
    success,
    responseTimeMs,
    inputTokens,
    outputTokens,
    outputReasoningTokens,
    costPollen,
    error
  };
}

async function benchmarkImage(model: string, prompt: string, width: number = 512, height: number = 512): Promise<BenchmarkResult> {
  console.log(`  Testing ${model} (${width}x${height})...`);
  
  const startTime = Date.now();
  let success = false;
  let error: string | undefined;
  let imageSize = 0;
  
  try {
    const url = `${BASE_URL}/image/${encodeURIComponent(prompt)}?model=${model}&width=${width}&height=${height}`;
    const r = await fetch(url, { headers: H });
    
    success = r.ok;
    
    if (r.ok) {
      const buffer = await r.arrayBuffer();
      imageSize = buffer.byteLength;
    } else {
      error = await r.text();
    }
  } catch (e: any) {
    error = e.message;
    success = false;
  }
  
  const responseTimeMs = Date.now() - startTime;
  
  await sleep(1500);
  
  const lastUsage = await getLastUsage();
  const costPollen = lastUsage?.cost_usd || 0;
  
  console.log(`    ✅ ${responseTimeMs}ms | ${Math.round(imageSize/1024)}KB | ${costPollen.toFixed(6)} pollen`);
  
  return {
    category: "IMAGE",
    model,
    method: "GET /image/{prompt}",
    success,
    responseTimeMs,
    imageSize,
    costPollen,
    error
  };
}

async function benchmarkVideo(model: string, prompt: string, duration: number = 4): Promise<BenchmarkResult> {
  console.log(`  Testing ${model} (${duration}s video)...`);
  
  const startTime = Date.now();
  let success = false;
  let error: string | undefined;
  let videoSize = 0;
  
  try {
    const url = `${BASE_URL}/image/${encodeURIComponent(prompt)}?model=${model}&duration=${duration}`;
    const r = await fetch(url, { headers: H });
    
    success = r.ok;
    
    if (r.ok) {
      const buffer = await r.arrayBuffer();
      videoSize = buffer.byteLength;
    } else {
      error = await r.text();
    }
  } catch (e: any) {
    error = e.message;
    success = false;
  }
  
  const responseTimeMs = Date.now() - startTime;
  
  await sleep(2000);
  
  const lastUsage = await getLastUsage();
  const costPollen = lastUsage?.cost_usd || 0;
  
  console.log(`    ✅ ${responseTimeMs}ms | ${Math.round(videoSize/1024)}KB | ${costPollen.toFixed(6)} pollen`);
  
  return {
    category: "VIDEO",
    model,
    method: "GET /image/{prompt} (video)",
    success,
    responseTimeMs,
    imageSize: videoSize,
    costPollen,
    error
  };
}

async function benchmarkTTS(model: string, text: string, voice: string = "alloy"): Promise<BenchmarkResult> {
  console.log(`  Testing ${model} (${text.length} chars)...`);
  
  const startTime = Date.now();
  let success = false;
  let error: string | undefined;
  let audioSize = 0;
  
  try {
    const r = await fetch(`${BASE_URL}/v1/audio/speech`, {
      method: "POST",
      headers: H,
      body: JSON.stringify({ model, input: text, voice })
    });
    
    success = r.ok;
    
    if (r.ok) {
      const buffer = await r.arrayBuffer();
      audioSize = buffer.byteLength;
    } else {
      error = await r.text();
    }
  } catch (e: any) {
    error = e.message;
    success = false;
  }
  
  const responseTimeMs = Date.now() - startTime;
  
  await sleep(1500);
  
  const lastUsage = await getLastUsage();
  const costPollen = lastUsage?.cost_usd || 0;
  const audioTokens = lastUsage?.output_audio_tokens || 0;
  
  console.log(`    ✅ ${responseTimeMs}ms | ${Math.round(audioSize/1024)}KB | ${costPollen.toFixed(6)} pollen`);
  
  return {
    category: "AUDIO_TTS",
    model,
    method: "POST /v1/audio/speech",
    success,
    responseTimeMs,
    outputAudioTokens: audioTokens,
    audioSize,
    costPollen,
    error
  };
}

async function benchmarkVision(model: string, prompt: string, imageUrl: string): Promise<BenchmarkResult> {
  console.log(`  Testing ${model} (vision)...`);
  
  const startTime = Date.now();
  let success = false;
  let error: string | undefined;
  let inputTokens = 0;
  let outputTokens = 0;
  let responsePreview = "";
  
  try {
    const r = await fetch(`${BASE_URL}/v1/chat/completions`, {
      method: "POST",
      headers: H,
      body: JSON.stringify({
        model,
        messages: [{
          role: "user",
          content: [
            { type: "text", text: prompt },
            { type: "image_url", image_url: { url: imageUrl } }
          ]
        }],
        max_tokens: 200
      })
    });
    
    const data = await r.json();
    success = r.ok;
    
    if (r.ok) {
      inputTokens = data.usage?.prompt_tokens || 0;
      outputTokens = data.usage?.completion_tokens || 0;
      responsePreview = data.choices?.[0]?.message?.content?.substring(0, 80) || "";
    } else {
      error = data.error?.message || JSON.stringify(data);
    }
  } catch (e: any) {
    error = e.message;
    success = false;
  }
  
  const responseTimeMs = Date.now() - startTime;
  
  await sleep(1500);
  
  const lastUsage = await getLastUsage();
  const costPollen = lastUsage?.cost_usd || 0;
  const imageTokens = lastUsage?.input_image_tokens || 0;
  
  console.log(`    ✅ ${responseTimeMs}ms | ${inputTokens}+${outputTokens} tokens | ${imageTokens} img tokens | ${costPollen.toFixed(6)} pollen`);
  
  return {
    category: "VISION",
    model,
    method: "POST /v1/chat/completions (vision)",
    success,
    responseTimeMs,
    inputTokens,
    outputTokens,
    outputImageTokens: imageTokens,
    costPollen,
    error
  };
}

// ============================================================
// MAIN BENCHMARK
// ============================================================

async function main() {
  console.log("=".repeat(90));
  console.log("🔬 BENCHMARK COMPLET - TOUS LES MODÈLES");
  console.log("=".repeat(90));
  
  const initialBalance = await getBalance();
  console.log(`\n💰 Solde initial: ${initialBalance} pollen\n`);
  
  // Récupérer la liste des modèles
  const [textModels, imageModels, audioModels] = await Promise.all([
    get<any[]>(`${BASE_URL}/text/models`),
    get<any[]>(`${BASE_URL}/image/models`),
    get<any[]>(`${BASE_URL}/audio/models`)
  ]);
  
  console.log(`📋 Modèles disponibles:`);
  console.log(`   TEXT: ${textModels.length} modèles`);
  console.log(`   IMAGE/VIDEO: ${imageModels.length} modèles`);
  console.log(`   AUDIO: ${audioModels.length} modèles\n`);
  
  // ============================================================
  // 1. TEXT MODELS
  // ============================================================
  console.log("=".repeat(90));
  console.log("📝 TEXT MODELS");
  console.log("=".repeat(90));
  
  // Test avec un prompt substantiel pour avoir de vraies réponses
  const textPrompt = "Explain what artificial intelligence is in 2-3 sentences. Be concise but informative.";
  
  // Modèles gratuits/économiques à tester
  const textModelsToTest = [
    "openai",           // GPT-5 Mini
    "openai-fast",      // GPT-5 Nano
    "mistral",          // Mistral Small
    "qwen-coder",       // Qwen3 Coder
    "gemini-fast",      // Gemini 2.5 Flash Lite
    "nova-fast",        // Amazon Nova Micro
  ];
  
  for (const model of textModelsToTest) {
    try {
      const result = await benchmarkText(model, textPrompt, 150);
      results.push(result);
    } catch (e: any) {
      console.log(`    ❌ Error: ${e.message}`);
      results.push({ category: "TEXT", model, method: "POST", success: false, responseTimeMs: 0, costPollen: 0, error: e.message });
    }
    await sleep(500);
  }
  
  // ============================================================
  // 2. IMAGE MODELS
  // ============================================================
  console.log("\n" + "=".repeat(90));
  console.log("🖼️ IMAGE MODELS");
  console.log("=".repeat(90));
  
  const imagePrompt = "a beautiful sunset over mountains with orange and purple sky";
  
  const imageModelsToTest = [
    "flux",       // Flux Schnell
    "zimage",     // Z-Image Turbo
    "imagen-4",   // Imagen 4
    "klein",      // FLUX.2 Klein 4B
  ];
  
  for (const model of imageModelsToTest) {
    try {
      const result = await benchmarkImage(model, imagePrompt, 512, 512);
      results.push(result);
    } catch (e: any) {
      console.log(`    ❌ Error: ${e.message}`);
      results.push({ category: "IMAGE", model, method: "GET", success: false, responseTimeMs: 0, costPollen: 0, error: e.message });
    }
    await sleep(500);
  }
  
  // ============================================================
  // 3. VIDEO MODELS (attention: coûteux!)
  // ============================================================
  console.log("\n" + "=".repeat(90));
  console.log("🎬 VIDEO MODELS");
  console.log("=".repeat(90));
  
  const videoPrompt = "a cat walking in a garden";
  
  // Seulement les modèles vidéo les moins chers
  const videoModelsToTest = [
    "grok-video",  // Le moins cher
  ];
  
  for (const model of videoModelsToTest) {
    try {
      const result = await benchmarkVideo(model, videoPrompt, 4);
      results.push(result);
    } catch (e: any) {
      console.log(`    ❌ Error: ${e.message}`);
      results.push({ category: "VIDEO", model, method: "GET", success: false, responseTimeMs: 0, costPollen: 0, error: e.message });
    }
    await sleep(500);
  }
  
  // ============================================================
  // 4. AUDIO MODELS (TTS)
  // ============================================================
  console.log("\n" + "=".repeat(90));
  console.log("🔊 AUDIO MODELS (TTS)");
  console.log("=".repeat(90));
  
  const ttsText = "Hello, this is a test of the text to speech system. We are measuring the quality and cost of the audio generation.";
  
  const audioModelsToTest = [
    "elevenlabs",
  ];
  
  for (const model of audioModelsToTest) {
    try {
      const result = await benchmarkTTS(model, ttsText, "alloy");
      results.push(result);
    } catch (e: any) {
      console.log(`    ❌ Error: ${e.message}`);
      results.push({ category: "AUDIO_TTS", model, method: "POST", success: false, responseTimeMs: 0, costPollen: 0, error: e.message });
    }
    await sleep(500);
  }
  
  // ============================================================
  // 5. VISION
  // ============================================================
  console.log("\n" + "=".repeat(90));
  console.log("👁️ VISION MODELS");
  console.log("=".repeat(90));
  
  const visionModelsToTest = ["openai", "gemini-fast"];
  
  for (const model of visionModelsToTest) {
    try {
      const result = await benchmarkVision(model, "Describe this image in detail.", "https://picsum.photos/400/300");
      results.push(result);
    } catch (e: any) {
      console.log(`    ❌ Error: ${e.message}`);
      results.push({ category: "VISION", model, method: "POST", success: false, responseTimeMs: 0, costPollen: 0, error: e.message });
    }
    await sleep(500);
  }
  
  // ============================================================
  // RÉSUMÉ
  // ============================================================
  console.log("\n\n" + "=".repeat(90));
  console.log("📊 RÉSUMÉ DU BENCHMARK");
  console.log("=".repeat(90));
  
  const finalBalance = await getBalance();
  const totalUsed = initialBalance - finalBalance;
  
  console.log(`\n💰 Balance:`);
  console.log(`   Initial: ${initialBalance.toFixed(6)} pollen`);
  console.log(`   Final: ${finalBalance.toFixed(6)} pollen`);
  console.log(`   Total utilisé: ${totalUsed.toFixed(6)} pollen`);
  
  console.log("\n📈 Résultats par catégorie:\n");
  
  // Tableau récapitulatif
  console.log("┌────────────┬──────────────────┬───────────┬─────────────┬─────────────┬─────────────────┐");
  console.log("│ Category   │ Model            │ Time (ms) │ Size/Token  │ Cost (pollen)│ Cost/Unit       │");
  console.log("├────────────┼──────────────────┼───────────┼─────────────┼─────────────┼─────────────────┤");
  
  for (const r of results) {
    if (!r.success) {
      console.log(`│ ${r.category.padEnd(10)} │ ${r.model.padEnd(16)} │ ERROR    │ -           │ -           │ -               │`);
      continue;
    }
    
    let sizeOrToken = "-";
    let costPerUnit = "-";
    
    if (r.category === "TEXT" || r.category === "VISION") {
      const total = (r.inputTokens || 0) + (r.outputTokens || 0);
      sizeOrToken = `${r.inputTokens}+${r.outputTokens}`;
      if (total > 0 && r.costPollen > 0) {
        costPerUnit = `${(r.costPollen / total * 1e6).toFixed(2)}/M`;
      }
    } else if (r.category === "IMAGE" || r.category === "VIDEO") {
      sizeOrToken = r.imageSize ? `${Math.round(r.imageSize/1024)}KB` : "-";
      if (r.costPollen > 0) {
        costPerUnit = r.category === "IMAGE" ? `${r.costPollen.toFixed(6)}/img` : `${r.costPollen.toFixed(4)}/vid`;
      }
    } else if (r.category === "AUDIO_TTS") {
      sizeOrToken = r.audioSize ? `${Math.round(r.audioSize/1024)}KB` : "-";
      if (r.outputAudioTokens && r.costPollen > 0) {
        costPerUnit = `${(r.costPollen / r.outputAudioTokens).toFixed(6)}/char`;
      }
    }
    
    console.log(`│ ${r.category.padEnd(10)} │ ${r.model.padEnd(16)} │ ${r.responseTimeMs.toString().padStart(9)} │ ${sizeOrToken.padStart(11)} │ ${r.costPollen.toFixed(6).padStart(11)} │ ${costPerUnit.padStart(15)} │`);
  }
  
  console.log("└────────────┴──────────────────┴───────────┴─────────────┴─────────────┴─────────────────┘");
  
  // Calcul du coût par type
  console.log("\n\n📊 COÛT MOYEN PAR TYPE DE REQUÊTE:\n");
  
  const textResults = results.filter(r => r.category === "TEXT" && r.success);
  const imageResults = results.filter(r => r.category === "IMAGE" && r.success);
  const videoResults = results.filter(r => r.category === "VIDEO" && r.success);
  const audioResults = results.filter(r => r.category === "AUDIO_TTS" && r.success);
  const visionResults = results.filter(r => r.category === "VISION" && r.success);
  
  if (textResults.length > 0) {
    const avgCost = textResults.reduce((a, b) => a + b.costPollen, 0) / textResults.length;
    const avgTokens = textResults.reduce((a, b) => a + (b.inputTokens || 0) + (b.outputTokens || 0), 0) / textResults.length;
    console.log(`   TEXT:   ~${avgCost.toFixed(6)} pollen/requête (~${avgTokens.toFixed(0)} tokens)`);
  }
  
  if (imageResults.length > 0) {
    const avgCost = imageResults.reduce((a, b) => a + b.costPollen, 0) / imageResults.length;
    const avgSize = imageResults.reduce((a, b) => a + (b.imageSize || 0), 0) / imageResults.length;
    console.log(`   IMAGE:  ~${avgCost.toFixed(6)} pollen/image (~${Math.round(avgSize/1024)}KB)`);
  }
  
  if (videoResults.length > 0) {
    const avgCost = videoResults.reduce((a, b) => a + b.costPollen, 0) / videoResults.length;
    console.log(`   VIDEO:  ~${avgCost.toFixed(4)} pollen/vidéo`);
  }
  
  if (audioResults.length > 0) {
    const avgCost = audioResults.reduce((a, b) => a + b.costPollen, 0) / audioResults.length;
    console.log(`   AUDIO:  ~${avgCost.toFixed(6)} pollen/requête TTS`);
  }
  
  if (visionResults.length > 0) {
    const avgCost = visionResults.reduce((a, b) => a + b.costPollen, 0) / visionResults.length;
    console.log(`   VISION: ~${avgCost.toFixed(6)} pollen/requête`);
  }
  
  // Sauvegarde
  const report = {
    timestamp: new Date().toISOString(),
    balance: { initial: initialBalance, final: finalBalance, used: totalUsed },
    results
  };
  
  await Bun.write("/home/z/my-project/download/benchmark_results.json", JSON.stringify(report, null, 2));
  console.log("\n📁 Résultats sauvegardés: /home/z/my-project/download/benchmark_results.json");
}

main().catch(console.error);
