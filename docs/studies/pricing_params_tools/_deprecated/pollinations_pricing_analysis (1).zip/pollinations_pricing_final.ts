#!/usr/bin/env bun
/**
 * pollinations_pricing_final.ts
 * 
 * Script de calcul de pricing DYNAMIQUE et REPRODUCTIBLE pour Pollinations AI
 * Version finale avec formules ajustées selon le dashboard de référence
 * 
 * Usage: bun run pollinations_pricing_final.ts [--api-key YOUR_KEY]
 */

const API_KEY = process.argv.includes("--api-key")
  ? process.argv[process.argv.indexOf("--api-key") + 1]
  : process.env.POLLINATIONS_API_KEY ?? "sk_iUdeP1sX21yJjGfuH6fHBPQN1nk1Mf1q";

const H: HeadersInit = API_KEY ? { Authorization: `Bearer ${API_KEY}` } : {};

async function get<T>(url: string): Promise<T> {
  const r = await fetch(url, { headers: H });
  if (!r.ok) throw new Error(`HTTP ${r.status} on ${url}`);
  return r.json();
}

// ============================================================
// CONSTANTES DE CALCUL - AJUSTÉES SELON LE DASHBOARD
// ============================================================

// Video: durée standard par modèle (en secondes)
const VIDEO_DURATION_BY_MODEL: Record<string, number> = {
  "grok-video": 5.33,
  "ltx-2": 6.67,
  "wan": 10,       // Wan fait des vidéos plus longues
  "veo": 6.67,
  "seedance": 167000,  // tokens mode
  "seedance-pro": 143000, // tokens mode
};

// Video tokens: tokens par vidéo par modèle
const VIDEO_TOKENS_BY_MODEL: Record<string, number> = {
  "seedance": 93000,
  "seedance-pro": 143000,
};

// Audio STT: secondes audio par request par modèle
const STT_SECONDS_BY_MODEL: Record<string, number> = {
  "scribe": 30,
  "whisper": 90,
};

// Audio TTS: caractères par request
const TTS_CHARS = 185;

// Audio Music: secondes par request
const MUSIC_SECONDS = 50;

// Text: paramètres spécifiques par modèle (input_tokens, output_tokens)
const TEXT_MODEL_PARAMS: Record<string, { input: number; output: number }> = {
  // Ultra-économiques
  "qwen-safety": { input: 100, output: 400 },
  "qwen-character": { input: 300, output: 3000 },
  "nova-fast": { input: 100, output: 344 },
  
  // Standards
  "mistral": { input: 200, output: 767 },
  "openai": { input: 200, output: 2331 },
  "grok": { input: 200, output: 1587 },
  "gemini": { input: 200, output: 3475 },
  
  // Fast/Search variants
  "gemini-search": { input: 200, output: 460 },
  "gemini-fast": { input: 200, output: 708 },
  "openai-fast": { input: 200, output: 3219 },
  "claude-fast": { input: 200, output: 1960 },
  
  // Code
  "qwen-coder": { input: 500, output: 4078 },
  
  // Reasoning
  "deepseek": { input: 500, output: 2314 },
  "minimax": { input: 500, output: 3283 },
  "perplexity-reasoning": { input: 200, output: 575 },
  "kimi": { input: 500, output: 3293 },
  "openai-large": { input: 200, output: 727 },
  "glm": { input: 500, output: 6006 },
  "gemini-large": { input: 350, output: 4500 },
  
  // Search
  "perplexity-fast": { input: 200, output: 976 },
  
  // Audio
  "openai-audio": { input: 200, output: 10051 },
  
  // Specialized
  "midijourney": { input: 200, output: 708 },
  "chickytutor": { input: 200, output: 2460 },
  
  // Premium
  "claude": { input: 500, output: 4404 },
  "claude-large": { input: 500, output: 5674 },
};

// Paramètres par défaut
const DEFAULT_TEXT_PARAMS = { input: 200, output: 500 };
const DEFAULT_VIDEO_DURATION = 5;
const DEFAULT_STT_SECONDS = 60;

// Image: tokens par image pour modèles token-based
const IMAGE_TOKENS_PER_IMAGE: Record<string, number> = {
  "gptimage": 1667,
  "gptimage-large": 2083,
  "nanobanana": 1333,
  "nanobanana-pro": 1190,
};

// ============================================================
// HELPER FUNCTIONS
// ============================================================

function n(v: unknown): number | null {
  const x = Number(v);
  return v === undefined || v === null || isNaN(x) || x === 0 ? null : x;
}

function flat(v: unknown, unit: string): string {
  const x = n(v); if (!x) return "—";
  if (x >= 1)      return `${x.toFixed(3)}/${unit}`;
  if (x >= 0.01)   return `${x.toFixed(4)}/${unit}`;
  if (x >= 0.001)  return `${x.toFixed(5)}/${unit}`;
  if (x >= 0.0001) return `${x.toFixed(6)}/${unit}`;
  return `${x.toFixed(7)}/${unit}`;
}

function perM(v: unknown): string {
  const x = n(v); if (!x) return "—";
  const m = x * 1_000_000;
  if (m >= 100) return `${m.toFixed(1)}/M`;
  if (m >= 10)  return `${m.toFixed(2)}/M`;
  if (m >= 1)   return `${m.toFixed(2)}/M`;
  return `${m.toFixed(2)}/M`;
}

function per1Kchars(v: unknown): string {
  const x = n(v); if (!x) return "—";
  const k = x * 1000;
  return `${k.toFixed(2)}/1K chars`;
}

function per1pollen(cost: number | null): string {
  if (!cost || cost <= 0) return "—";
  const x = 1 / cost;
  if (x >= 10000)  return `${Math.round(x/1000)}K`;
  if (x >= 1000)   return `${Math.round(x/100)*100}`.replace(/(\d)(?=(\d{3})+$)/g, "$1,");
  if (x >= 100)    return `${Math.round(x)}`;
  if (x >= 10)     return `${Math.round(x)}`;
  return `${x.toFixed(1)}`;
}

// ============================================================
// TYPES
// ============================================================

interface BaseModel {
  name: string;
  description?: string;
  paid_only?: boolean;
  pricing?: Record<string, unknown>;
  [k: string]: unknown;
}

interface TextModel extends BaseModel {
  input_modalities?: string[];
  output_modalities?: string[];
  tools?: boolean;
  reasoning?: boolean;
  context_window?: number;
}

// ============================================================
// CAPABILITY FLAGS
// ============================================================

function tmFlags(m: TextModel): string {
  const f: string[] = [];
  if (m.paid_only)                             f.push("💎 PAID ONLY");
  if (m.input_modalities?.includes("image"))   f.push("👁️");
  if (m.input_modalities?.includes("audio"))   f.push("🎙️");
  if (m.output_modalities?.includes("audio"))  f.push("🔊");
  if (m.reasoning)                             f.push("🧠");
  if (m.tools === false)                       f.push("🔍");
  if ((m.context_window ?? 0) >= 100_000)      f.push(`📏${((m.context_window??0)/1000).toFixed(0)}k`);
  return f.join(" ");
}

function mmFlags(m: BaseModel, hasImageInput: boolean = false): string {
  const f: string[] = [];
  if (m.paid_only) f.push("💎 PAID ONLY");
  if (hasImageInput) f.push("👁️");
  return f.join(" ");
}

function isNew(m: BaseModel): boolean {
  return (m.description ?? "").includes("NEW") || 
         (m as any).is_new === true;
}

// ============================================================
// MEDIA HELPERS
// ============================================================

function isVideo(m: BaseModel): boolean {
  const pr = m.pricing ?? {};
  return pr.completionVideoSeconds !== undefined || pr.completionVideoTokens !== undefined;
}

function isSTT(m: BaseModel): boolean {
  const d = (m.description ?? "").toLowerCase();
  return d.includes("speech to text") || d.includes("transcri")
    || m.name.includes("whisper") || m.name.includes("scribe");
}

function isMusic(m: BaseModel): boolean {
  return m.name.includes("music") || m.name.includes("elevenmusic");
}

// ============================================================
// RENDER FUNCTIONS
// ============================================================

function renderImage(models: BaseModel[]): string {
  const imgs = models.filter(m => !isVideo(m));
  const lines = [
    "# Image\n",
    "**1 pollen ≈ images**\n",
    "| Model | Flags | ID | images pour 1 pollen | Pricing |",
    "|---|---|---|---|---|",
  ];
  
  // Sort by cost (most expensive last = least images per pollen first)
  const sorted = [...imgs].sort((a, b) => {
    const costA = n(a.pricing?.completionImageTokens) ?? Infinity;
    const costB = n(b.pricing?.completionImageTokens) ?? Infinity;
    return costA - costB;
  });
  
  for (const m of sorted) {
    const pr = m.pricing ?? {};
    const hasTokens = pr.promptTextTokens !== undefined;
    let pricing = "";
    let cost: number | null = null;
    
    const hasImageInput = (m as any).input_modalities?.includes("image") || hasTokens;
    const flags = mmFlags(m, hasImageInput);
    const displayName = (m.description ?? m.name).split(" - ")[0];
    
    if (hasTokens) {
      const ptt = n(pr.promptTextTokens);
      const pit = n(pr.promptImageTokens);
      const cit = n(pr.completionImageTokens);
      
      pricing = [
        ptt ? `💬 ${perM(ptt)}` : "",
        pit ? `🖼️ ${perM(pit)}` : "",
        cit ? `🖼️ ${perM(cit)}` : "",
      ].filter(Boolean).join(" · ");
      
      const tokensPerImage = IMAGE_TOKENS_PER_IMAGE[m.name] ?? 1500;
      cost = cit ? cit * tokensPerImage : null;
    } else {
      const cit = n(pr.completionImageTokens);
      pricing = cit ? `🖼️ ${flat(cit, "img")}` : "—";
      cost = cit;
    }
    
    lines.push(`| ${displayName} | ${flags} | ${m.name} | ${per1pollen(cost)} | ${pricing} |`);
  }
  return lines.join("\n");
}

function renderVideo(models: BaseModel[]): string {
  const vids = models.filter(m => isVideo(m));
  const lines = [
    "\n---\n",
    "# Video\n",
    "**1 pollen ≈ videos**\n",
    "| Model | Flags | ID | vidéos pour 1 pollen | Pricing |",
    "|---|---|---|---|---|",
  ];
  
  const sorted = [...vids].sort((a, b) => {
    const costA = n(a.pricing?.completionVideoSeconds) ?? n(a.pricing?.completionVideoTokens) ?? Infinity;
    const costB = n(b.pricing?.completionVideoSeconds) ?? n(b.pricing?.completionVideoTokens) ?? Infinity;
    return costA - costB;
  });
  
  for (const m of sorted) {
    const pr = m.pricing ?? {};
    const parts: string[] = [];
    let cost: number | null = null;
    
    const cvs = n(pr.completionVideoSeconds);
    const cvt = n(pr.completionVideoTokens);
    const cas = n(pr.completionAudioSeconds);
    
    if (cvs) {
      parts.push(`🎬 ${flat(cvs, "sec")}`);
      const duration = VIDEO_DURATION_BY_MODEL[m.name] ?? DEFAULT_VIDEO_DURATION;
      cost = cvs * duration;
    } else if (cvt) {
      parts.push(`🎬 ${perM(cvt)}`);
      const tokens = VIDEO_TOKENS_BY_MODEL[m.name] ?? 140000;
      cost = cvt * tokens;
    }
    
    if (cas) parts.push(`🔊 ${flat(cas, "sec")}`);
    
    const flags = mmFlags(m, true);
    const displayName = (m.description ?? m.name).split(" - ")[0];
    
    lines.push(`| ${displayName} | ${flags} | ${m.name} | ${per1pollen(cost)} | ${parts.join(" · ") || "—"} |`);
  }
  return lines.join("\n");
}

function renderAudio(models: BaseModel[]): string {
  const tts = models.filter(m => !isSTT(m) && !isMusic(m));
  const stt = models.filter(m => isSTT(m));
  const music = models.filter(m => isMusic(m));
  
  const lines = [
    "\n---\n",
    "# Audio\n",
    "**1 pollen ≈ requests**\n",
    "| Model | Flags | ID | requests pour 1 pollen | Pricing |",
    "|---|---|---|---|---|",
  ];
  
  for (const m of stt) {
    const pr = m.pricing ?? {};
    const pas = n(pr.promptAudioSeconds);
    const pricing = pas ? `🎬 ${flat(pas, "sec")}` : "—";
    const seconds = STT_SECONDS_BY_MODEL[m.name] ?? DEFAULT_STT_SECONDS;
    const cost = pas ? pas * seconds : null;
    const displayName = (m.description ?? m.name).split(" - ")[0];
    lines.push(`| ${displayName} | 🎙️ | ${m.name} | ${per1pollen(cost)} | ${pricing} |`);
  }
  
  for (const m of tts) {
    const pr = m.pricing ?? {};
    const cat = n(pr.completionAudioTokens);
    const pricing = cat ? `🔊 ${per1Kchars(cat)}` : "—";
    const cost = cat ? cat * TTS_CHARS : null;
    const displayName = (m.description ?? m.name).split(" - ")[0];
    lines.push(`| ${displayName} | 🔊 | ${m.name} | ${per1pollen(cost)} | ${pricing} |`);
  }
  
  for (const m of music) {
    const pr = m.pricing ?? {};
    const cas = n(pr.completionAudioSeconds);
    const pricing = cas ? `🎬 ${flat(cas, "sec")}` : "—";
    const cost = cas ? cas * MUSIC_SECONDS : null;
    const displayName = (m.description ?? m.name).split(" - ")[0];
    lines.push(`| ${displayName} | 🔊 | ${m.name} | ${per1pollen(cost)} | ${pricing} |`);
  }
  
  return lines.join("\n");
}

function renderText(models: TextModel[]): string {
  const avgCost = (m: TextModel) => {
    const p = m.pricing ?? {};
    const i = n(p.promptTextTokens) ?? 0;
    const o = n(p.completionTextTokens) ?? 0;
    return (i + o) / 2;
  };
  const sorted = [...models].sort((a, b) => avgCost(b) - avgCost(a));
  
  const lines = [
    "\n---\n",
    "# Text\n",
    "**1 pollen ≈ responses**\n",
    "| Model | Flags | ID | Réponses pour 1 pollen | Pricing |",
    "|---|---|---|---|---|",
  ];
  
  for (const m of sorted) {
    const pr = m.pricing ?? {};
    const parts: string[] = [];
    
    const ptt = n(pr.promptTextTokens);
    const pct = n(pr.promptCachedTokens);
    const pat = n(pr.promptAudioTokens);
    const ctt = n(pr.completionTextTokens);
    const cat = n(pr.completionAudioTokens);
    
    if (ptt) parts.push(`💬 ${perM(ptt)}`);
    if (pct) parts.push(`💾 ${perM(pct)}`);
    if (pat) parts.push(`🔊 ${perM(pat)}`);
    if (ctt) parts.push(`💬 ${perM(ctt)}`);
    if (pat && m.output_modalities?.includes("audio") && cat) {
      parts.push(`🔊 ${perM(cat)}`);
    }
    
    const params = TEXT_MODEL_PARAMS[m.name] ?? DEFAULT_TEXT_PARAMS;
    const cost = (ptt ?? 0) * params.input + (ctt ?? 0) * params.output;
    
    const displayName = (m.description ?? m.name).split(" - ")[0];
    
    lines.push(`| ${displayName} | ${tmFlags(m)} | ${m.name} | ${per1pollen(cost)} | ${parts.join(" · ")} |`);
  }
  
  return lines.join("\n");
}

// ============================================================
// MAIN
// ============================================================

async function main() {
  console.error("Fetching API data...");
  
  const [text, img, aud] = await Promise.all([
    get<TextModel[]>("https://gen.pollinations.ai/text/models"),
    get<BaseModel[]>("https://gen.pollinations.ai/image/models"),
    get<BaseModel[]>("https://gen.pollinations.ai/audio/models"),
  ]);
  
  console.error(`Got ${text.length} text, ${img.length} image, ${aud.length} audio models`);
  
  console.log(`# 🌸 Pollinations — Live Model Pricing`);
  console.log(`> **${new Date().toISOString()}** · ${img.length} image · ${aud.length} audio · ${text.length} text\n`);
  console.log(renderImage(img));
  console.log(renderVideo(img));
  console.log(renderAudio(aud));
  console.log(renderText(text));
  console.log(`
---

# Model Capabilities

👁️ vision  
🧠 reasoning  
🎙️ audio in  
🔍 search  
🔊 audio out  
💻 code exec  

---

# Token Types

💬 text  
🖼️ image  
💾 cached  
🎬 video  
🔊 audio  

---

# Pricing Metrics

/img = flat rate per image  
/M = per million tokens  
/sec = per second of video  
/1K chars = per 1000 characters
`);
}

main().catch(console.error);
