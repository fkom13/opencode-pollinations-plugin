#!/usr/bin/env bun
/**
 * pollinations_cost_estimator_final.ts
 * 
 * Estimateur de coût FINAL - Basé sur les données réelles
 * avec analyse complète des modèles et endpoints
 */

const API_KEY = "sk_iUdeP1sX21yJjGfuH6fHBPQN1nk1Mf1q";
const BASE_URL = "https://gen.pollinations.ai";

const H: HeadersInit = {
  "Authorization": `Bearer ${API_KEY}`,
  "Content-Type": "application/json"
};

// ============================================================
// DONNÉES DE RÉFÉRENCE - Basées sur les tests réels
// ============================================================

// Coûts réels mesurés (en pollen)
const REAL_COSTS = {
  // TEXT - coût par 1M tokens (input + output combinés typiquement)
  text: {
    "qwen-safety": { perMillion: 0.05, description: "Ultra cheap safety model" },
    "qwen-character": { perMillion: 0.05, description: "Character roleplay" },
    "nova-fast": { perMillion: 0.15, description: "Amazon Nova Micro" },
    "gemini-fast": { perMillion: 0.15, description: "Gemini 2.5 Flash Lite" },
    "gemini-search": { perMillion: 0.15, description: "Gemini with search" },
    "qwen-coder": { perMillion: 0.14, description: "Code specialist" },
    "openai": { perMillion: 0.17, description: "GPT-5 Mini" },
    "openai-fast": { perMillion: 0.17, description: "GPT-5 Nano" },
    "mistral": { perMillion: 0.24, description: "Mistral Small 3.2" },
    "grok": { perMillion: 0.35, description: "xAI Grok 4 Fast" },
    "perplexity-fast": { perMillion: 1.00, description: "Perplexity Sonar" },
    "deepseek": { perMillion: 0.70, description: "DeepSeek V3.2" },
    "minimax": { perMillion: 0.45, description: "MiniMax M2.1" },
    "kimi": { perMillion: 0.80, description: "Moonshot Kimi K2.5" },
    "openai-large": { perMillion: 3.50, description: "GPT-5.2 Reasoning" },
    "gemini": { perMillion: 1.00, description: "Gemini 3 Flash" },
    "claude-fast": { perMillion: 3.00, description: "Claude Haiku 4.5" },
    "claude": { perMillion: 9.00, description: "Claude Sonnet 4.5" },
    "claude-large": { perMillion: 15.00, description: "Claude Opus 4.6" },
  },
  
  // IMAGE - coût par image
  image: {
    "flux": { perImage: 0.0002, description: "Flux Schnell - Fast" },
    "zimage": { perImage: 0.0002, description: "Z-Image Turbo" },
    "imagen-4": { perImage: 0.0025, description: "Google Imagen 4" },
    "klein": { perImage: 0.008, description: "FLUX.2 Klein 4B" },
    "klein-large": { perImage: 0.012, description: "FLUX.2 Klein 9B" },
    "gptimage": { perImage: 0.013, description: "GPT Image 1 Mini" },
    "seedream": { perImage: 0.03, description: "Seedream 4.0" },
    "kontext": { perImage: 0.04, description: "FLUX.1 Kontext" },
    "seedream-pro": { perImage: 0.04, description: "Seedream 4.5 Pro" },
    "gptimage-large": { perImage: 0.066, description: "GPT Image 1.5" },
    "nanobanana": { perImage: 0.04, description: "NanoBanana" },
    "nanobanana-pro": { perImage: 0.14, description: "NanoBanana Pro" },
  },
  
  // VIDEO - coût par seconde
  video: {
    "grok-video": { perSecond: 0.0025, description: "Grok Video" },
    "ltx-2": { perSecond: 0.01, description: "LTX-2" },
    "wan": { perSecond: 0.0125, description: "Wan 2.6" },
    "seedance": { perSecond: 0.0018, description: "Seedance Lite (token-based)" },
    "seedance-pro": { perSecond: 0.001, description: "Seedance Pro (token-based)" },
    "veo": { perSecond: 0.15, description: "Veo 3.1 Fast" },
  },
  
  // AUDIO TTS - coût par caractère
  audio_tts: {
    "elevenlabs": { perChar: 0.00018, description: "ElevenLabs v3 TTS" },
  },
  
  // AUDIO STT - coût par seconde
  audio_stt: {
    "whisper": { perSecond: 0.000045, description: "Whisper Large V3" },
    "scribe": { perSecond: 0.00011, description: "ElevenLabs Scribe v2" },
  },
  
  // AUDIO Music - coût par seconde
  audio_music: {
    "elevenmusic": { perSecond: 0.005, description: "ElevenLabs Music" },
  }
};

// ============================================================
// HELPER FUNCTIONS
// ============================================================

async function get<T>(url: string): Promise<T> {
  const r = await fetch(url, { headers: H });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}

function formatNumber(n: number): string {
  if (n >= 1000000) return `${(n/1000000).toFixed(1)}M`;
  if (n >= 1000) return `${(n/1000).toFixed(1)}K`;
  return n.toString();
}

// ============================================================
// MAIN
// ============================================================

async function main() {
  console.log("=".repeat(100));
  console.log("💰 POLLINATIONS AI - COST ESTIMATOR FINAL");
  console.log("=".repeat(100));
  
  // Récupérer le solde actuel
  const balance = await get<{ balance: number }>(`${BASE_URL}/account/balance`);
  const currentBalance = balance.balance;
  
  console.log(`\n💵 Solde actuel: ${currentBalance.toFixed(2)} pollen\n`);
  
  // ============================================================
  // TABLEAU ESTIMATEUR COMPLET
  // ============================================================
  
  console.log("╔" + "═".repeat(98) + "╗");
  console.log("║" + " ESTIMATEUR DE CAPACITÉ - Combien pouvez-vous générer avec votre solde?".padEnd(98) + "║");
  console.log("╠" + "═".repeat(98) + "╣");
  console.log("║ Type     │ Model               │ Cost Unit        │ Capacity                          │ Description                      ║");
  console.log("╠" + "─".repeat(10) + "┼" + "─".repeat(20) + "┼" + "─".repeat(18) + "┼" + "─".repeat(35) + "┼" + "─".repeat(33) + "╣");
  
  // TEXT
  console.log("║ TEXT     │                     │                  │                                   │                                  ║");
  for (const [model, data] of Object.entries(REAL_COSTS.text).sort((a, b) => a[1].perMillion - b[1].perMillion)) {
    const costPerMillion = data.perMillion;
    const tokens = Math.floor(currentBalance / (costPerMillion / 1000000));
    const requests = Math.floor(tokens / 500); // ~500 tokens par requête moyenne
    const capacity = `${formatNumber(tokens)} tokens (~${formatNumber(requests)} req)`;
    console.log(`║          │ ${model.padEnd(18)} │ ${costPerMillion.toFixed(2)}/M tokens`.padEnd(27) + `│ ${capacity.padEnd(34)}│ ${data.description.padEnd(32)}║`);
  }
  
  console.log("╠" + "─".repeat(10) + "┼" + "─".repeat(20) + "┼" + "─".repeat(18) + "┼" + "─".repeat(35) + "┼" + "─".repeat(33) + "╣");
  
  // IMAGE
  console.log("║ IMAGE    │                     │                  │                                   │                                  ║");
  for (const [model, data] of Object.entries(REAL_COSTS.image).sort((a, b) => a[1].perImage - b[1].perImage)) {
    const images = Math.floor(currentBalance / data.perImage);
    const capacity = `${formatNumber(images)} images`;
    console.log(`║          │ ${model.padEnd(18)} │ ${data.perImage.toFixed(6)}/img`.padEnd(27) + `│ ${capacity.padEnd(34)}│ ${data.description.padEnd(32)}║`);
  }
  
  console.log("╠" + "─".repeat(10) + "┼" + "─".repeat(20) + "┼" + "─".repeat(18) + "┼" + "─".repeat(35) + "┼" + "─".repeat(33) + "╣");
  
  // VIDEO
  console.log("║ VIDEO    │                     │                  │                                   │                                  ║");
  for (const [model, data] of Object.entries(REAL_COSTS.video).sort((a, b) => a[1].perSecond - b[1].perSecond)) {
    const seconds = Math.floor(currentBalance / data.perSecond);
    const videos = Math.floor(seconds / 5); // ~5 sec par vidéo
    const capacity = `${formatNumber(seconds)} sec (~${formatNumber(videos)} videos)`;
    console.log(`║          │ ${model.padEnd(18)} │ ${data.perSecond.toFixed(4)}/sec`.padEnd(27) + `│ ${capacity.padEnd(34)}│ ${data.description.padEnd(32)}║`);
  }
  
  console.log("╠" + "─".repeat(10) + "┼" + "─".repeat(20) + "┼" + "─".repeat(18) + "┼" + "─".repeat(35) + "┼" + "─".repeat(33) + "╣");
  
  // AUDIO
  console.log("║ AUDIO    │                     │                  │                                   │                                  ║");
  
  // TTS
  for (const [model, data] of Object.entries(REAL_COSTS.audio_tts)) {
    const chars = Math.floor(currentBalance / data.perChar);
    const requests = Math.floor(chars / 100); // ~100 chars par requête
    const capacity = `${formatNumber(chars)} chars (~${formatNumber(requests)} req)`;
    console.log(`║ TTS      │ ${model.padEnd(18)} │ ${data.perChar.toFixed(6)}/char`.padEnd(27) + `│ ${capacity.padEnd(34)}│ ${data.description.padEnd(32)}║`);
  }
  
  // STT
  for (const [model, data] of Object.entries(REAL_COSTS.audio_stt)) {
    const seconds = Math.floor(currentBalance / data.perSecond);
    const requests = Math.floor(seconds / 60); // ~60 sec par requête
    const capacity = `${formatNumber(seconds)} sec (~${formatNumber(requests)} req)`;
    console.log(`║ STT      │ ${model.padEnd(18)} │ ${data.perSecond.toFixed(6)}/sec`.padEnd(27) + `│ ${capacity.padEnd(34)}│ ${data.description.padEnd(32)}║`);
  }
  
  // Music
  for (const [model, data] of Object.entries(REAL_COSTS.audio_music)) {
    const seconds = Math.floor(currentBalance / data.perSecond);
    const songs = Math.floor(seconds / 30); // ~30 sec par chanson
    const capacity = `${formatNumber(seconds)} sec (~${songs} songs)`;
    console.log(`║ MUSIC    │ ${model.padEnd(18)} │ ${data.perSecond.toFixed(4)}/sec`.padEnd(27) + `│ ${capacity.padEnd(34)}│ ${data.description.padEnd(32)}║`);
  }
  
  console.log("╚" + "═".repeat(10) + "╧" + "═".repeat(20) + "╧" + "═".repeat(18) + "╧" + "═".repeat(35) + "╧" + "═".repeat(33) + "╝");
  
  // ============================================================
  // RÉSUMÉ PAR TYPE D'USAGE
  // ============================================================
  
  console.log("\n\n" + "=".repeat(100));
  console.log("📊 RÉSUMÉ PAR TYPE D'USAGE");
  console.log("=".repeat(100));
  
  console.log(`
┌─────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ 💬 TEXT GENERATION                                                                                  │
├─────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Coût = (input_tokens × input_rate) + (output_tokens × output_rate)                                  │
│                                                                                                     │
│ Exemple avec 200 input + 300 output tokens:                                                         │
│   • qwen-safety (le plus cheap):   ~0.000025 pollen  →  ~40,000 requêtes par pollen                │
│   • nova-fast:                     ~0.000075 pollen  →  ~13,000 requêtes par pollen                │
│   • openai (GPT-5 Mini):           ~0.000105 pollen  →  ~9,500 requêtes par pollen                 │
│   • mistral:                       ~0.000120 pollen  →  ~8,300 requêtes par pollen                 │
│   • claude-large (premium):        ~0.013500 pollen  →  ~74 requêtes par pollen                    │
├─────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ 🖼️ IMAGE GENERATION                                                                                 │
├─────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Coût = flat_rate par image (ne dépend pas de la résolution)                                         │
│                                                                                                     │
│   • flux/zimage (le plus cheap):   0.0002 pollen/img →  5,000 images par pollen                    │
│   • imagen-4:                      0.0025 pollen/img →    400 images par pollen                    │
│   • gptimage:                      0.013  pollen/img →     77 images par pollen                    │
│   • kontext/seedream-pro:          0.04   pollen/img →     25 images par pollen                    │
├─────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ 🎬 VIDEO GENERATION                                                                                 │
├─────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Coût = duration_seconds × rate_per_second                                                           │
│                                                                                                     │
│ Pour une vidéo de 5 secondes:                                                                       │
│   • grok-video:                    0.0125 pollen → 80 videos par pollen                             │
│   • ltx-2:                         0.05   pollen → 20 videos par pollen                             │
│   • wan (avec audio):              0.125  pollen → 8 videos par pollen                              │
│   • veo:                           0.75   pollen → 1.3 videos par pollen                            │
├─────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ 🔊 AUDIO - TEXT TO SPEECH (TTS)                                                                     │
├─────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Coût = characters × rate_per_char (1 token ≈ 1 char)                                                │
│                                                                                                     │
│   • elevenlabs:  0.00018 pollen/char → ~5,555 chars par pollen → ~55 requests de 100 chars         │
├─────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ 🎙️ AUDIO - SPEECH TO TEXT (STT)                                                                     │
├─────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Coût = audio_seconds × rate_per_second                                                              │
│                                                                                                     │
│   • whisper:    0.000045 pollen/sec → ~22,222 sec par pollen → ~370 min d'audio par pollen         │
│   • scribe:     0.00011  pollen/sec → ~9,090 sec par pollen → ~151 min d'audio par pollen          │
└─────────────────────────────────────────────────────────────────────────────────────────────────────┘
`);
  
  // ============================================================
  // FORMULES DÉTAILLÉES
  // ============================================================
  
  console.log("=".repeat(100));
  console.log("📐 FORMULES DE CALCUL");
  console.log("=".repeat(100));
  
  console.log(`
TEXT:
  cost_pollen = (promptTextTokens × rate_in + completionTextTokens × rate_out)
  
  Où rate_in et rate_out viennent de /text/models:
    - promptTextTokens: coût par token d'entrée
    - completionTextTokens: coût par token de sortie

IMAGE:
  cost_pollen = completionImageTokens  (flat rate)
  
  Pour les modèles token-based (gptimage, nanobanana):
    cost ≈ completionImageTokens × tokens_per_image (~1200-1700)

VIDEO:
  cost_pollen = completionVideoSeconds × duration
  OU
  cost_pollen = completionVideoTokens × tokens_per_video (~100k-150k)

AUDIO TTS:
  cost_pollen = completionAudioTokens × characters
  (1 token ≈ 1 caractère)

AUDIO STT:
  cost_pollen = promptAudioSeconds × audio_seconds

VISION:
  cost_pollen = (text_tokens × rate) + (image_tokens × rate_image)
  Les tokens d'image coûtent plus que les tokens texte
`);
  
  // Sauvegarde
  const report = {
    timestamp: new Date().toISOString(),
    balance: currentBalance,
    costs: REAL_COSTS,
    estimates: {
      text: Object.fromEntries(
        Object.entries(REAL_COSTS.text).map(([k, v]) => [
          k, 
          { costPerMillionTokens: v.perMillion, tokensWithCurrentBalance: Math.floor(currentBalance / (v.perMillion / 1000000)) }
        ])
      ),
      image: Object.fromEntries(
        Object.entries(REAL_COSTS.image).map(([k, v]) => [
          k, 
          { costPerImage: v.perImage, imagesWithCurrentBalance: Math.floor(currentBalance / v.perImage) }
        ])
      ),
      video: Object.fromEntries(
        Object.entries(REAL_COSTS.video).map(([k, v]) => [
          k, 
          { costPerSecond: v.perSecond, secondsWithCurrentBalance: Math.floor(currentBalance / v.perSecond) }
        ])
      ),
      audio_tts: Object.fromEntries(
        Object.entries(REAL_COSTS.audio_tts).map(([k, v]) => [
          k, 
          { costPerChar: v.perChar, charsWithCurrentBalance: Math.floor(currentBalance / v.perChar) }
        ])
      ),
      audio_stt: Object.fromEntries(
        Object.entries(REAL_COSTS.audio_stt).map(([k, v]) => [
          k, 
          { costPerSecond: v.perSecond, secondsWithCurrentBalance: Math.floor(currentBalance / v.perSecond) }
        ])
      ),
    }
  };
  
  await Bun.write("/home/z/my-project/download/cost_estimator_final.json", JSON.stringify(report, null, 2));
  console.log("\n📁 Rapport: /home/z/my-project/download/cost_estimator_final.json");
}

main().catch(console.error);
