#!/usr/bin/env bun
/**
 * pollinations_account_analyzer.ts
 * 
 * Analyse complète des endpoints de compte pour comprendre la facturation
 * - /account/balance
 * - /account/usage  
 * - /account/usage/daily
 * - /account/profile
 * - /account/key
 */

const API_KEY = "sk_iUdeP1sX21yJjGfuH6fHBPQN1nk1Mf1q";
const BASE_URL = "https://gen.pollinations.ai";

const H: HeadersInit = {
  "Authorization": `Bearer ${API_KEY}`,
  "Content-Type": "application/json"
};

async function get<T>(url: string): Promise<T> {
  const r = await fetch(url, { headers: H });
  if (!r.ok) {
    const text = await r.text();
    throw new Error(`HTTP ${r.status}: ${text}`);
  }
  return r.json();
}

async function main() {
  console.log("=".repeat(90));
  console.log("📊 ANALYSE DES ENDPOINTS DE COMPTE");
  console.log("=".repeat(90));
  
  // ============================================================
  // 1. ACCOUNT PROFILE
  // ============================================================
  console.log("\n┌─────────────────────────────────────────────────────────────────────────┐");
  console.log("│ 1. ACCOUNT PROFILE                                                       │");
  console.log("└─────────────────────────────────────────────────────────────────────────┘\n");
  
  try {
    const profile = await get<any>(`${BASE_URL}/account/profile`);
    console.log(JSON.stringify(profile, null, 2));
  } catch (e: any) {
    console.log("Erreur:", e.message);
  }
  
  // ============================================================
  // 2. ACCOUNT BALANCE
  // ============================================================
  console.log("\n┌─────────────────────────────────────────────────────────────────────────┐");
  console.log("│ 2. ACCOUNT BALANCE                                                       │");
  console.log("└─────────────────────────────────────────────────────────────────────────┘\n");
  
  try {
    const balance = await get<any>(`${BASE_URL}/account/balance`);
    console.log(JSON.stringify(balance, null, 2));
  } catch (e: any) {
    console.log("Erreur:", e.message);
  }
  
  // ============================================================
  // 3. ACCOUNT KEY INFO
  // ============================================================
  console.log("\n┌─────────────────────────────────────────────────────────────────────────┐");
  console.log("│ 3. ACCOUNT KEY INFO                                                      │");
  console.log("└─────────────────────────────────────────────────────────────────────────┘\n");
  
  try {
    const keyInfo = await get<any>(`${BASE_URL}/account/key`);
    console.log(JSON.stringify(keyInfo, null, 2));
  } catch (e: any) {
    console.log("Erreur:", e.message);
  }
  
  // ============================================================
  // 4. ACCOUNT USAGE (temps réel, limité à 100)
  // ============================================================
  console.log("\n┌─────────────────────────────────────────────────────────────────────────┐");
  console.log("│ 4. ACCOUNT USAGE (temps réel)                                            │");
  console.log("└─────────────────────────────────────────────────────────────────────────┘\n");
  
  try {
    const usage = await get<any>(`${BASE_URL}/account/usage?limit=50`);
    console.log(`Count: ${usage.count}`);
    console.log("\nDernières requêtes:");
    
    if (usage.usage && usage.usage.length > 0) {
      // Afficher les 10 dernières
      for (let i = 0; i < Math.min(10, usage.usage.length); i++) {
        const u = usage.usage[i];
        console.log(`\n--- Requête ${i + 1} ---`);
        console.log(`  Timestamp: ${u.timestamp}`);
        console.log(`  Model: ${u.model}`);
        console.log(`  Type: ${u.type}`);
        console.log(`  Input text tokens: ${u.input_text_tokens || 0}`);
        console.log(`  Input cached tokens: ${u.input_cached_tokens || 0}`);
        console.log(`  Input image tokens: ${u.input_image_tokens || 0}`);
        console.log(`  Input audio tokens: ${u.input_audio_tokens || 0}`);
        console.log(`  Output text tokens: ${u.output_text_tokens || 0}`);
        console.log(`  Output reasoning tokens: ${u.output_reasoning_tokens || 0}`);
        console.log(`  Output image tokens: ${u.output_image_tokens || 0}`);
        console.log(`  Output audio tokens: ${u.output_audio_tokens || 0}`);
        console.log(`  Cost USD: ${u.cost_usd || 0}`);
        console.log(`  Response time: ${u.response_time_ms || 0}ms`);
      }
    }
  } catch (e: any) {
    console.log("Erreur:", e.message);
  }
  
  // ============================================================
  // 5. ACCOUNT USAGE DAILY (aggrégé, pas temps réel)
  // ============================================================
  console.log("\n\n┌─────────────────────────────────────────────────────────────────────────┐");
  console.log("│ 5. ACCOUNT USAGE DAILY (aggrégé, cached 1h)                             │");
  console.log("└─────────────────────────────────────────────────────────────────────────┘\n");
  
  try {
    const daily = await get<any>(`${BASE_URL}/account/usage/daily`);
    console.log(`Count: ${daily.count}`);
    
    if (daily.usage && daily.usage.length > 0) {
      console.log("\nDerniers jours:");
      for (const d of daily.usage.slice(0, 10)) {
        console.log(`  ${d.date} | ${d.model.padEnd(20)} | ${d.requests} req | $${d.cost_usd?.toFixed(6) || 0}`);
      }
    }
  } catch (e: any) {
    console.log("Erreur:", e.message);
  }
  
  // ============================================================
  // 6. ANALYSE DE LA STRUCTURE DE COÛT
  // ============================================================
  console.log("\n\n┌─────────────────────────────────────────────────────────────────────────┐");
  console.log("│ 6. ANALYSE DE LA STRUCTURE DE COÛT                                      │");
  console.log("└─────────────────────────────────────────────────────────────────────────┘\n");
  
  try {
    const usage = await get<any>(`${BASE_URL}/account/usage?limit=100`);
    
    if (usage.usage && usage.usage.length > 0) {
      // Grouper par modèle
      const byModel: Record<string, { count: number; totalCost: number; totalTokens: number }> = {};
      
      for (const u of usage.usage) {
        const model = u.model || "unknown";
        if (!byModel[model]) {
          byModel[model] = { count: 0, totalCost: 0, totalTokens: 0 };
        }
        byModel[model].count++;
        byModel[model].totalCost += u.cost_usd || 0;
        byModel[model].totalTokens += (u.input_text_tokens || 0) + (u.output_text_tokens || 0);
      }
      
      console.log("Consommation par modèle:\n");
      console.log("Model".padEnd(25) + "| Requests".padStart(10) + "| Cost USD".padStart(12) + "| Tokens".padStart(10));
      console.log("-".repeat(60));
      
      for (const [model, data] of Object.entries(byModel).sort((a, b) => b[1].totalCost - a[1].totalCost)) {
        console.log(
          `${model.padEnd(25)}| ${data.count.toString().padStart(8)}| ` +
          `$${data.totalCost.toFixed(6).padStart(9)}| ${data.totalTokens.toString().padStart(8)}`
        );
      }
    }
  } catch (e: any) {
    console.log("Erreur:", e.message);
  }
  
  console.log("\n\n" + "=".repeat(90));
  console.log("CONCLUSIONS");
  console.log("=".repeat(90));
  console.log(`
📝 NOTES IMPORTANTES:

1. /account/usage → TEMPS RÉEL, limité à 100 requêtes
   - Utiliser pour mesurer le coût exact d'une requête immédiatement après l'exécution
   
2. /account/usage/daily → AGGRÉGÉ, cache 1 heure
   - NE PAS utiliser pour des mesures en temps réel
   
3. /account/balance → Solde du compte (pollen)
   - Mis à jour après chaque requête

4. Le coût est en USD dans usage, mais le solde est en pollen
   - 1 pollen ≈ 1 USD (à vérifier)

5. Pour le cost estimator:
   - Faire 1 requête
   - Attendre 500ms
   - Vérifier /account/usage pour la dernière entrée
   - Le cost_usd = pollen consommé
`);
}

main().catch(console.error);
