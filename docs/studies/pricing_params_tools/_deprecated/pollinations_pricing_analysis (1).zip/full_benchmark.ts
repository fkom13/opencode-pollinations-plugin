#!/usr/bin/env bun
/**
 * pollinations_full_benchmark.ts
 * 
 * Benchmark complet et précis de TOUS les modèles accessibles
 * avec mesure réelle du coût via /account/usage
 */

const API_KEY = "sk_iUdeP1sX21yJjGfuH6fHBPQN1nk1Mf1q";
const BASE_URL = "https://gen.pollinations.ai";

const H: HeadersInit = {
  "Authorization": `Bearer ${API_KEY}`,
  "Content-Type": "application/json"
};

interface ModelResult {
  category: string;
  model: string;
  success: boolean;
  responseTimeMs: number;
  costPollen: number;
  inputTokens?: number;
  outputTokens?: number;
  outputImageTokens?: number;
  outputAudioTokens?: number;
  outputVideoSeconds?: number;
  imageSize?: number;
  audioSize?: number;
  costPerUnit: string;
  requestsPerPollen: string;
  error?: string;
}

const results: ModelResult[] = [];

async function get<T>(url: string): Promise<T> {
  const r = await fetch(url, { headers: H });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}

async function getLastUsage(): Promise<any> {
  await sleep(2000); // Attendre que l'usage soit enregistré
  const usage = await get<any>(`${BASE_URL}/account/usage?limit=1`);
  return usage.usage?.[0];
}

async function getBalance(): Promise<number> {
  const data = await get<{ balance: number }>(`${BASE_URL}/account/balance`);
  return data.balance;
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ============================================================
// TEXT BENCHMARK
// ============================================================
async function benchmarkText(model: string): Promise<ModelResult> {
  console.log(`  TEXT: ${model}...`);
  
  const prompt = "Explain artificial intelligence in exactly 2 sentences.";
  const startTime = Date.now();
  
  try {
    const r = await fetch(`${BASE_URL}/v1/chat/completions`, {
      method: "POST",
      headers: H,
      body: JSON.stringify({
        model,
        messages: [{ role: "user", content: prompt }],
        max_tokens: 100
      })
    });
    
    const data = await r.json();
    const responseTimeMs = Date.now() - startTime;
    
    if (!r.ok) {
      return { category: "TEXT", model, success: false, responseTimeMs: 0, costPollen: 0, costPerUnit: "-", requestsPerPollen: "-", error: data.error?.message };
    }
    
    const usage = await getLastUsage();
    const costPollen = usage?.cost_usd || 0;
    const inputTokens = usage?.input_text_tokens || data.usage?.prompt_tokens || 0;
    const outputTokens = usage?.output_text_tokens || data.usage?.completion_tokens || 0;
    const reasoningTokens = usage?.output_reasoning_tokens || 0;
    
    const totalTokens = inputTokens + outputTokens + reasoningTokens;
    const costPerUnit = totalTokens > 0 ? `${(costPollen / totalTokens * 1e6).toFixed(2)}/M` : "-";
    const requestsPerPollen = costPollen > 0 ? Math.round(1 / costPollen).toString() : "-";
    
    console.log(`    ✅ ${responseTimeMs}ms | ${inputTokens}+${outputTokens}+${reasoningTokens}R tokens | ${costPollen.toFixed(6)} pollen`);
    
    return {
      category: "TEXT",
      model,
      success: true,
      responseTimeMs,
      costPollen,
      inputTokens,
      outputTokens: outputTokens + reasoningTokens,
      costPerUnit,
      requestsPerPollen
    };
  } catch (e: any) {
    return { category: "TEXT", model, success: false, responseTimeMs: 0, costPollen: 0, costPerUnit: "-", requestsPerPollen: "-", error: e.message };
  }
}

// ============================================================
// IMAGE BENCHMARK
// ============================================================
async function benchmarkImage(model: string, prompt: string = "a red circle"): Promise<ModelResult> {
  console.log(`  IMAGE: ${model}...`);
  
  const startTime = Date.now();
  
  try {
    const r = await fetch(`${BASE_URL}/image/${encodeURIComponent(prompt)}?model=${model}&width=256&height=256`, { headers: H });
    const buffer = await r.arrayBuffer();
    const responseTimeMs = Date.now() - startTime;
    
    if (!r.ok) {
      return { category: "IMAGE", model, success: false, responseTimeMs: 0, costPollen: 0, costPerUnit: "-", requestsPerPollen: "-", error: await r.text() };
    }
    
    const usage = await getLastUsage();
    const costPollen = usage?.cost_usd || 0;
    
    const costPerUnit = `${costPollen.toFixed(6)}/img`;
    const requestsPerPollen = costPollen > 0 ? Math.round(1 / costPollen).toString() : "-";
    
    console.log(`    ✅ ${responseTimeMs}ms | ${Math.round(buffer.byteLength/1024)}KB | ${costPollen.toFixed(6)} pollen`);
    
    return {
      category: "IMAGE",
      model,
      success: true,
      responseTimeMs,
      costPollen,
      imageSize: buffer.byteLength,
      costPerUnit,
      requestsPerPollen
    };
  } catch (e: any) {
    return { category: "IMAGE", model, success: false, responseTimeMs: 0, costPollen: 0, costPerUnit: "-", requestsPerPollen: "-", error: e.message };
  }
}

// ============================================================
// AUDIO TTS BENCHMARK
// ============================================================
async function benchmarkTTS(model: string): Promise<ModelResult> {
  console.log(`  AUDIO: ${model}...`);
  
  const text = "Hello world, this is a test.";
  const startTime = Date.now();
  
  try {
    const r = await fetch(`${BASE_URL}/v1/audio/speech`, {
      method: "POST",
      headers: H,
      body: JSON.stringify({ model, input: text, voice: "alloy" })
    });
    
    const buffer = await r.arrayBuffer();
    const responseTimeMs = Date.now() - startTime;
    
    if (!r.ok) {
      return { category: "AUDIO_TTS", model, success: false, responseTimeMs: 0, costPollen: 0, costPerUnit: "-", requestsPerPollen: "-", error: await r.text() };
    }
    
    const usage = await getLastUsage();
    const costPollen = usage?.cost_usd || 0;
    const audioTokens = usage?.output_audio_tokens || 0;
    
    const costPerUnit = audioTokens > 0 ? `${(costPollen / audioTokens).toFixed(6)}/char` : `${costPollen.toFixed(6)}/req`;
    const requestsPerPollen = costPollen > 0 ? Math.round(1 / costPollen).toString() : "-";
    
    console.log(`    ✅ ${responseTimeMs}ms | ${Math.round(buffer.byteLength/1024)}KB | ${audioTokens} chars | ${costPollen.toFixed(6)} pollen`);
    
    return {
      category: "AUDIO_TTS",
      model,
      success: true,
      responseTimeMs,
      costPollen,
      outputAudioTokens: audioTokens,
      audioSize: buffer.byteLength,
      costPerUnit,
      requestsPerPollen
    };
  } catch (e: any) {
    return { category: "AUDIO_TTS", model, success: false, responseTimeMs: 0, costPollen: 0, costPerUnit: "-", requestsPerPollen: "-", error: e.message };
  }
}

// ============================================================
// MAIN
// ============================================================
async function main() {
  console.log("=".repeat(90));
  console.log("🔬 BENCHMARK COMPLET - TOUS LES MODÈLES ACCESSIBLES");
  console.log("=".repeat(90));
  
  const initialBalance = await getBalance();
  console.log(`\n💰 Solde initial: ${initialBalance.toFixed(6)} pollen\n`);
  
  // ============================================================
  // TEXT MODELS
  // ============================================================
  console.log("┌─────────────────────────────────────────────────────────────────────────┐");
  console.log("│ 📝 TEXT MODELS                                                          │");
  console.log("└─────────────────────────────────────────────────────────────────────────┘\n");
  
  const textModels = [
    "openai", "openai-fast", "mistral", "qwen-coder", 
    "gemini-fast", "nova-fast", "qwen-safety"
  ];
  
  for (const model of textModels) {
    const result = await benchmarkText(model);
    results.push(result);
    await sleep(500);
  }
  
  // ============================================================
  // IMAGE MODELS
  // ============================================================
  console.log("\n┌─────────────────────────────────────────────────────────────────────────┐");
  console.log("│ 🖼️ IMAGE MODELS                                                         │");
  console.log("└─────────────────────────────────────────────────────────────────────────┘\n");
  
  const imageModels = ["flux", "zimage", "klein", "imagen-4", "kontext"];
  
  for (const model of imageModels) {
    const result = await benchmarkImage(model);
    results.push(result);
    await sleep(500);
  }
  
  // ============================================================
  // AUDIO MODELS
  // ============================================================
  console.log("\n┌─────────────────────────────────────────────────────────────────────────┐");
  console.log("│ 🔊 AUDIO MODELS                                                         │");
  console.log("└─────────────────────────────────────────────────────────────────────────┘\n");
  
  const audioModels = ["elevenlabs"];
  
  for (const model of audioModels) {
    const result = await benchmarkTTS(model);
    results.push(result);
    await sleep(500);
  }
  
  // ============================================================
  // RÉSUMÉ
  // ============================================================
  console.log("\n\n" + "=".repeat(90));
  console.log("📊 TABLEAU RÉCAPITULATIF");
  console.log("=".repeat(90));
  
  const finalBalance = await getBalance();
  
  console.log(`\n💰 Balance: ${initialBalance.toFixed(6)} → ${finalBalance.toFixed(6)} (utilisé: ${(initialBalance - finalBalance).toFixed(6)} pollen)\n`);
  
  // Grouper par catégorie
  const categories = ["TEXT", "IMAGE", "AUDIO_TTS"];
  
  for (const cat of categories) {
    const catResults = results.filter(r => r.category === cat);
    if (catResults.length === 0) continue;
    
    console.log(`\n${cat === "TEXT" ? "📝" : cat === "IMAGE" ? "🖼️" : "🔊"} ${cat}`);
    console.log("─".repeat(80));
    console.log("Model               | Status | Time    | Cost/Unit      | Requests/Pollen");
    console.log("─".repeat(80));
    
    for (const r of catResults.sort((a, b) => a.costPollen - b.costPollen)) {
      const status = r.success ? "✅" : "❌";
      const time = r.success ? `${r.responseTimeMs}ms` : "-";
      console.log(
        `${r.model.padEnd(19)} | ${status}   | ${time.padEnd(7)} | ${r.costPerUnit.padEnd(14)} | ${r.requestsPerPollen}`
      );
    }
  }
  
  // ============================================================
  // ESTIMATEUR DE CAPACITÉ
  // ============================================================
  console.log("\n\n" + "=".repeat(90));
  console.log("🎯 ESTIMATEUR - Combien pouvez-vous faire avec votre solde?");
  console.log("=".repeat(90));
  
  console.log(`\nAvec ${finalBalance.toFixed(2)} pollen, vous pouvez:\n`);
  
  // Calculer les capacités
  const successful = results.filter(r => r.success && r.costPollen > 0);
  
  for (const r of successful.sort((a, b) => a.costPollen - b.costPollen).slice(0, 15)) {
    const count = Math.floor(finalBalance / r.costPollen);
    const unit = r.category === "TEXT" ? "requêtes" : (r.category === "IMAGE" ? "images" : "audio");
    console.log(`  • ${r.model.padEnd(15)} → ${count.toLocaleString()} ${unit}`);
  }
  
  // ============================================================
  // SAUVEGARDE
  // ============================================================
  const report = {
    timestamp: new Date().toISOString(),
    balance: { initial: initialBalance, final: finalBalance, used: initialBalance - finalBalance },
    results,
    capacityEstimate: successful.map(r => ({
      model: r.model,
      category: r.category,
      costPerRequest: r.costPollen,
      requestsWithCurrentBalance: Math.floor(finalBalance / r.costPollen)
    }))
  };
  
  await Bun.write("/home/z/my-project/download/full_benchmark_results.json", JSON.stringify(report, null, 2));
  console.log("\n📁 Résultats: /home/z/my-project/download/full_benchmark_results.json");
}

main().catch(console.error);
