Fetching API data...
Got 25 text, 18 image, 4 audio models
# 🌸 Pollinations — Live Model Pricing
> **2026-02-19T08:19:47.900Z** · 18 image · 4 audio · 25 text

# Image

**1 pollen ≈ images**

| Model | Flags | ID | images pour 1 pollen | Pricing |
|---|---|---|---|---|
| GPT Image 1 Mini | 👁️ | gptimage | 75 | 💬 2.00/M · 🖼️ 2.50/M · 🖼️ 8.00/M |
| NanoBanana | 💎 PAID ONLY 👁️ | nanobanana | 25 | 💬 0.30/M · 🖼️ 0.30/M · 🖼️ 30.00/M |
| GPT Image 1.5 | 💎 PAID ONLY 👁️ | gptimage-large | 15 | 💬 8.00/M · 🖼️ 8.00/M · 🖼️ 32.00/M |
| NanoBanana Pro | 💎 PAID ONLY 👁️ | nanobanana-pro | 7.0 | 💬 1.25/M · 🖼️ 1.25/M · 🖼️ 120.0/M |
| Flux Schnell |  | flux | 5,000 | 🖼️ 0.000200/img |
| Z-Image Turbo |  | zimage | 5,000 | 🖼️ 0.000200/img |
| Imagen 4 (api.airforce) |  | imagen-4 | 400 | 🖼️ 0.00250/img |
| FLUX.2 Klein 4B | 👁️ | klein | 125 | 🖼️ 0.00800/img |
| FLUX.2 Klein 9B | 👁️ | klein-large | 83 | 🖼️ 0.0120/img |
| Seedream 4.0 | 💎 PAID ONLY 👁️ | seedream | 33 | 🖼️ 0.0300/img |
| FLUX.1 Kontext | 💎 PAID ONLY 👁️ | kontext | 25 | 🖼️ 0.0400/img |
| Seedream 4.5 Pro | 💎 PAID ONLY 👁️ | seedream-pro | 25 | 🖼️ 0.0400/img |

---

# Video

**1 pollen ≈ videos**

| Model | Flags | ID | vidéos pour 1 pollen | Pricing |
|---|---|---|---|---|
| Seedance Pro-Fast | 💎 PAID ONLY 👁️ | seedance-pro | 7.0 | 🎬 1.00/M |
| Seedance Lite | 👁️ | seedance | 6.0 | 🎬 1.80/M |
| Grok Video (api.airforce) | 👁️ | grok-video | 75 | 🎬 0.00250/sec |
| LTX-2 | 💎 PAID ONLY 👁️ | ltx-2 | 15 | 🎬 0.0100/sec |
| Wan 2.6 | 👁️ | wan | 8.0 | 🎬 0.0125/sec · 🔊 0.0125/sec |
| Veo 3.1 Fast | 💎 PAID ONLY 👁️ | veo | 1.0 | 🎬 0.1500/sec |

---

# Audio

**1 pollen ≈ requests**

| Model | Flags | ID | requests pour 1 pollen | Pricing |
|---|---|---|---|---|
| Whisper Large V3 | 🎙️ | whisper | 250 | 🎬 0.0000445/sec |
| ElevenLabs Scribe v2 | 🎙️ | scribe | 300 | 🎬 0.000111/sec |
| ElevenLabs v3 TTS | 🔊 | elevenlabs | 30 | 🔊 0.18/1K chars |
| ElevenLabs Music | 🔊 | elevenmusic | 4.0 | 🎬 0.00500/sec |

---

# Text

**1 pollen ≈ responses**

| Model | Flags | ID | Réponses pour 1 pollen | Pricing |
|---|---|---|---|---|
| Anthropic Claude Opus 4.6 | 💎 PAID ONLY 👁️ | claude-large | 6.9 | 💬 5.00/M · 💬 25.00/M |
| Anthropic Claude Sonnet 4.5 | 💎 PAID ONLY 👁️ | claude | 15 | 💬 3.00/M · 💬 15.00/M |
| OpenAI GPT-5.2 | 👁️ 🧠 | openai-large | 95 | 💬 1.75/M · 💾 0.17/M · 💬 14.00/M |
| Google Gemini 3 Pro | 💎 PAID ONLY 👁️ 🎙️ 🧠 | gemini-large | 18 | 💬 2.00/M · 💾 0.20/M · 💬 12.00/M |
| MIDIjourney |  | midijourney | 150 | 💬 2.20/M · 💾 0.55/M · 💬 8.80/M |
| Perplexity Sonar Reasoning | 🧠 🔍 | perplexity-reasoning | 200 | 💬 2.00/M · 💬 8.00/M |
| Anthropic Claude Haiku 4.5 | 👁️ | claude-fast | 100 | 💬 1.00/M · 💬 5.00/M |
| ChickyTutor AI Language Tutor |  | chickytutor | 100 | 💬 0.80/M · 💬 4.00/M |
| Moonshot Kimi K2.5 | 👁️ 🧠 📏256k | kimi | 98 | 💬 0.60/M · 💾 0.10/M · 💬 3.00/M |
| Google Gemini 3 Flash | 💎 PAID ONLY 👁️ 🎙️ | gemini | 95 | 💬 0.50/M · 💾 0.05/M · 🔊 0.50/M · 💬 3.00/M |
| Z.ai GLM-5 | 🧠 📏198k | glm | 74 | 💬 0.60/M · 💾 0.30/M · 💬 2.20/M |
| DeepSeek V3.2 | 🧠 | deepseek | 240 | 💬 0.56/M · 💾 0.28/M · 💬 1.68/M |
| Perplexity Sonar | 🔍 | perplexity-fast | 850 | 💬 1.00/M · 💬 1.00/M |
| MiniMax M2.1 | 🧠 📏200k | minimax | 245 | 💬 0.30/M · 💾 0.15/M · 💬 1.20/M |
| OpenAI GPT-4o Mini Audio | 👁️ 🎙️ 🔊 | openai-audio | 150 | 💬 0.17/M · 🔊 11.00/M · 💬 0.66/M · 🔊 22.00/M |
| OpenAI GPT-5 Mini | 👁️ | openai | 700 | 💬 0.15/M · 💾 0.04/M · 💬 0.60/M |
| xAI Grok 4 Fast | 💎 PAID ONLY | grok | 1,200 | 💬 0.20/M · 💾 0.20/M · 💬 0.50/M |
| Google Gemini 2.5 Flash Lite | 👁️ | gemini-fast | 3,300 | 💬 0.10/M · 💾 0.01/M · 🔊 0.10/M · 💬 0.40/M |
| Google Gemini 2.5 Flash Lite | 👁️ 🔍 | gemini-search | 4,900 | 💬 0.10/M · 💾 0.01/M · 🔊 0.10/M · 💬 0.40/M |
| OpenAI GPT-5 Nano | 👁️ | openai-fast | 700 | 💬 0.06/M · 💾 0.01/M · 💬 0.44/M |
| Mistral Small 3.2 24B |  | mistral | 4,000 | 💬 0.10/M · 💬 0.30/M |
| Qwen3 Coder 30B |  | qwen-coder | 1,100 | 💬 0.06/M · 💬 0.22/M |
| Amazon Nova Micro |  | nova-fast | 19K | 💬 0.04/M · 💬 0.14/M |
| Qwen3Guard 8B |  | qwen-safety | 200K | 💬 0.01/M · 💬 0.01/M |
| Qwen Character (api.airforce) |  | qwen-character | 30K | 💬 0.01/M · 💬 0.01/M |

---

# Model Capabilities

👁️ vision  
🧠 reasoning  
🎙️ audio in  
🔍 search  
🔊 audio out  
💻 code exec  

---

# Token Types

💬 text  
🖼️ image  
💾 cached  
🎬 video  
🔊 audio  

---

# Pricing Metrics

/img = flat rate per image  
/M = per million tokens  
/sec = per second of video  
/1K chars = per 1000 characters

