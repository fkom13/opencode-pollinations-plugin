# Documentation des Formules de Pricing Pollinations AI

## Résumé Exécutif

Cette documentation présente les formules de calcul découvertes pour générer le dashboard de pricing Pollinations AI de manière **dynamique et reproductible**.

---

## Endpoints API

| Endpoint | Description |
|----------|-------------|
| `GET https://gen.pollinations.ai/text/models` | Tous les modèles text/chat avec métadonnées complètes |
| `GET https://gen.pollinations.ai/image/models` | Tous les modèles image ET vidéo avec métadonnées complètes |
| `GET https://gen.pollinations.ai/audio/models` | Tous les modèles TTS ET musique avec métadonnées complètes |

---

## Formules de Calcul par Catégorie

### 1. IMAGE - Modèles Flat-Rate

**Modèles concernés:** flux, zimage, seedream, kontext, klein, imagen-4, etc.

**Formule:**
```
images_par_pollen = 1 / completionImageTokens
```

**Exemple:**
- flux: `completionImageTokens = 0.0002`
- `images_par_pollen = 1 / 0.0002 = 5000` ✅

**Note:** `completionImageTokens` représente le coût DIRECT par image pour ces modèles.

---

### 2. IMAGE - Modèles Token-Based

**Modèles concernés:** gptimage, gptimage-large, nanobanana, nanobanana-pro

**Formule:**
```
coût_par_image = completionImageTokens × tokens_par_image
images_par_pollen = 1 / coût_par_image
```

**Tokens par image estimés:**
| Modèle | Tokens/Image |
|--------|-------------|
| gptimage | 1667 |
| gptimage-large | 2083 |
| nanobanana | 1333 |
| nanobanana-pro | 1190 |

**Exemple:**
- gptimage: `completionImageTokens = 0.000008` (8/M)
- `coût = 0.000008 × 1667 = 0.0133`
- `images_par_pollen = 1 / 0.0133 = 75` ✅

---

### 3. VIDEO - Par Seconde

**Modèles concernés:** grok-video, ltx-2, wan, veo

**Formule:**
```
coût_par_vidéo = completionVideoSeconds × durée_estimée
vidéos_par_pollen = 1 / coût_par_vidéo
```

**Durées estimées par modèle:**
| Modèle | Durée (sec) |
|--------|------------|
| grok-video | 5.33 |
| ltx-2 | 6.67 |
| wan | 10 |
| veo | 6.67 |

**Exemple:**
- grok-video: `completionVideoSeconds = 0.0025`
- `coût = 0.0025 × 5.33 = 0.0133`
- `vidéos_par_pollen = 1 / 0.0133 = 75` ✅

---

### 4. VIDEO - Par Tokens

**Modèles concernés:** seedance, seedance-pro

**Formule:**
```
coût_par_vidéo = completionVideoTokens × tokens_par_vidéo
vidéos_par_pollen = 1 / coût_par_vidéo
```

**Tokens par vidéo estimés:**
| Modèle | Tokens/Vidéo |
|--------|-------------|
| seedance | 93,000 |
| seedance-pro | 143,000 |

---

### 5. AUDIO - STT (Speech-to-Text)

**Modèles concernés:** whisper, scribe

**Formule:**
```
coût_par_request = promptAudioSeconds × secondes_estimées
requests_par_pollen = 1 / coût_par_request
```

**Secondes par request:**
| Modèle | Secondes |
|--------|---------|
| whisper | 90 |
| scribe | 30 |

---

### 6. AUDIO - TTS (Text-to-Speech)

**Modèles concernés:** elevenlabs

**Formule:**
```
coût_par_request = completionAudioTokens × caractères_estimés
requests_par_pollen = 1 / coût_par_request
```

**Caractères par request:** 185

**Note:** `completionAudioTokens` = coût par caractère (1 token ≈ 1 char)

---

### 7. AUDIO - Music

**Modèles concernés:** elevenmusic

**Formule:**
```
coût_par_request = completionAudioSeconds × secondes_estimées
requests_par_pollen = 1 / coût_par_request
```

**Secondes par request:** 50

---

### 8. TEXT - Modèles Chat

**Formule générale:**
```
coût_par_response = (promptTextTokens × INPUT) + (completionTextTokens × OUTPUT)
responses_par_pollen = 1 / coût_par_response
```

**Paramètres INPUT/OUTPUT par type de modèle:**

| Type | Modèles | INPUT | OUTPUT |
|------|---------|-------|--------|
| Ultra-économique | qwen-safety, nova-fast | 100 | 300-400 |
| Standard | mistral, openai, grok, gemini | 200 | 1500-3500 |
| Fast/Search | gemini-fast, gemini-search, openai-fast | 200 | 450-3200 |
| Code | qwen-coder | 500 | 4000 |
| Reasoning | deepseek, minimax, kimi, glm | 500 | 2300-6000 |
| Premium | claude, claude-large | 500 | 4400-5700 |
| Specialized | midijourney, chickytutor | 200 | 700-2500 |

**Exemple:**
- mistral: `ptt = 0.0000001, ctt = 0.0000003`
- `coût = (0.0000001 × 200) + (0.0000003 × 767) = 0.00025`
- `responses = 1 / 0.00025 = 4000` ✅

---

## Formatage des Prix

### Affichage par million de tokens (/M)
```typescript
function perM(v: number): string {
  return `${(v * 1_000_000).toFixed(2)}/M`;
}
```

### Affichage taux flat (/img, /sec)
```typescript
function flat(v: number, unit: string): string {
  // Ajuste les décimales selon l'ordre de grandeur
  if (v >= 1) return `${v.toFixed(3)}/${unit}`;
  if (v >= 0.01) return `${v.toFixed(4)}/${unit}`;
  // ...
}
```

### Affichage par 1000 caractères
```typescript
function per1Kchars(v: number): string {
  return `${(v * 1000).toFixed(2)}/1K chars`;
}
```

---

## Drapeaux de Capacités

| Drapeau | Signification | Détection |
|---------|--------------|-----------|
| 👁️ | Vision (image input) | `input_modalities.includes("image")` |
| 🧠 | Reasoning | `reasoning === true` |
| 🎙️ | Audio input | `input_modalities.includes("audio")` |
| 🔊 | Audio output | `output_modalities.includes("audio")` |
| 🔍 | Search | `tools === false` |
| 💎 | Paid only | `paid_only === true` |
| 📏Nk | Context window | `context_window >= 100000` |

---

## Reproductibilité

Le script `pollinations_pricing_final.ts` est **totalement dynamique**:

1. Il interroge les 3 endpoints API en temps réel
2. Il applique les formules documentées ci-dessus
3. Il génère un dashboard markdown identique au format de référence

### Usage
```bash
bun run pollinations_pricing_final.ts --api-key YOUR_KEY
```

### Sortie
Le script génère un markdown complet avec:
- Tables par catégorie (Image, Video, Audio, Text)
- Tri par coût croissant
- Drapeaux de capacités
- Prix formatés selon les conventions

---

## Limitations et Notes

1. **Valeurs estimées:** Certains paramètres (durées vidéo, tokens par image, etc.) sont des estimations basées sur le dashboard de référence. Ils peuvent nécessiter des ajustements si l'API change.

2. **Nouveaux modèles:** Les nouveaux modèles utiliseront les paramètres par défaut:
   - TEXT: INPUT=200, OUTPUT=500
   - VIDEO: durée=5 secondes
   - IMAGE: tokens=1500

3. **Précision:** Les calculs peuvent différer légèrement (±10%) du dashboard officiel en raison d'arrondis ou de mises à jour.

---

## Fichiers Générés

| Fichier | Description |
|---------|-------------|
| `pollinations_pricing_final.ts` | Script principal reproductible |
| `raw-api-data.json` | Données brutes de l'API |
| `generated_pricing_dashboard.md` | Dashboard généré |
| `PRICING_FORMULAS.md` | Cette documentation |
