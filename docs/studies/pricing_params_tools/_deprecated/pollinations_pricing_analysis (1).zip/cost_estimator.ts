#!/usr/bin/env bun
/**
 * pollinations_cost_estimator.ts
 * 
 * Estimateur de coût par type de requête - Test réel des endpoints
 * Ce script effectue des requêtes réelles pour mesurer la consommation de pollen
 */

const API_KEY = "sk_iUdeP1sX21yJjGfuH6fHBPQN1nk1Mf1q";
const BASE_URL = "https://gen.pollinations.ai";

const H: HeadersInit = {
  "Authorization": `Bearer ${API_KEY}`,
  "Content-Type": "application/json"
};

// ============================================================
// UTILITIES
// ============================================================

async function getBalance(): Promise<number> {
  const r = await fetch(`${BASE_URL}/account/balance`, { headers: H });
  if (!r.ok) throw new Error(`Balance check failed: ${r.status}`);
  const data = await r.json();
  return data.balance;
}

async function getUsage(): Promise<any[]> {
  const r = await fetch(`${BASE_URL}/account/usage?limit=50`, { headers: H });
  if (!r.ok) throw new Error(`Usage check failed: ${r.status}`);
  const data = await r.json();
  return data.usage || [];
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ============================================================
// TEST FUNCTIONS
// ============================================================

interface TestResult {
  category: string;
  model: string;
  method: string;
  endpoint: string;
  success: boolean;
  pollenBefore: number;
  pollenAfter: number;
  pollenUsed: number;
  responseTime: number;
  details: Record<string, any>;
  error?: string;
}

const results: TestResult[] = [];

async function testTextGeneration(model: string, prompt: string, maxTokens: number = 100): Promise<TestResult> {
  const pollenBefore = await getBalance();
  const startTime = Date.now();
  
  let success = false;
  let error: string | undefined;
  let details: Record<string, any> = {};
  
  try {
    const r = await fetch(`${BASE_URL}/v1/chat/completions`, {
      method: "POST",
      headers: H,
      body: JSON.stringify({
        model: model,
        messages: [{ role: "user", content: prompt }],
        max_tokens: maxTokens
      })
    });
    
    const data = await r.json();
    success = r.ok;
    
    if (r.ok) {
      details = {
        promptTokens: data.usage?.prompt_tokens,
        completionTokens: data.usage?.completion_tokens,
        totalTokens: data.usage?.total_tokens,
        responsePreview: data.choices?.[0]?.message?.content?.substring(0, 100)
      };
    } else {
      error = data.error?.message || JSON.stringify(data);
    }
  } catch (e: any) {
    error = e.message;
  }
  
  const responseTime = Date.now() - startTime;
  await sleep(500); // Wait for balance to update
  const pollenAfter = await getBalance();
  
  return {
    category: "TEXT",
    model,
    method: "POST /v1/chat/completions",
    endpoint: "/v1/chat/completions",
    success,
    pollenBefore,
    pollenAfter,
    pollenUsed: pollenBefore - pollenAfter,
    responseTime,
    details,
    error
  };
}

async function testSimpleText(model: string, prompt: string): Promise<TestResult> {
  const pollenBefore = await getBalance();
  const startTime = Date.now();
  
  let success = false;
  let error: string | undefined;
  let details: Record<string, any> = {};
  let text = "";
  
  try {
    const r = await fetch(`${BASE_URL}/text/${encodeURIComponent(prompt)}?model=${model}`, {
      headers: H
    });
    
    text = await r.text();
    success = r.ok;
    
    if (r.ok) {
      details = {
        responseLength: text.length,
        responsePreview: text.substring(0, 100)
      };
    } else {
      error = text;
    }
  } catch (e: any) {
    error = e.message;
  }
  
  const responseTime = Date.now() - startTime;
  await sleep(500);
  const pollenAfter = await getBalance();
  
  return {
    category: "TEXT",
    model,
    method: "GET /text/{prompt}",
    endpoint: "/text/{prompt}",
    success,
    pollenBefore,
    pollenAfter,
    pollenUsed: pollenBefore - pollenAfter,
    responseTime,
    details,
    error
  };
}

async function testImageGeneration(model: string, prompt: string, width: number = 512, height: number = 512): Promise<TestResult> {
  const pollenBefore = await getBalance();
  const startTime = Date.now();
  
  let success = false;
  let error: string | undefined;
  let details: Record<string, any> = {};
  
  try {
    const url = `${BASE_URL}/image/${encodeURIComponent(prompt)}?model=${model}&width=${width}&height=${height}`;
    const r = await fetch(url, { headers: H });
    
    const contentType = r.headers.get("content-type") || "";
    success = r.ok;
    
    if (r.ok) {
      const buffer = await r.arrayBuffer();
      details = {
        contentType,
        sizeBytes: buffer.byteLength,
        sizeKB: Math.round(buffer.byteLength / 1024)
      };
    } else {
      const text = await r.text();
      error = text;
    }
  } catch (e: any) {
    error = e.message;
  }
  
  const responseTime = Date.now() - startTime;
  await sleep(500);
  const pollenAfter = await getBalance();
  
  return {
    category: "IMAGE",
    model,
    method: "GET /image/{prompt}",
    endpoint: "/image/{prompt}",
    success,
    pollenBefore,
    pollenAfter,
    pollenUsed: pollenBefore - pollenAfter,
    responseTime,
    details,
    error
  };
}

async function testTTS(model: string, text: string, voice: string = "alloy"): Promise<TestResult> {
  const pollenBefore = await getBalance();
  const startTime = Date.now();
  
  let success = false;
  let error: string | undefined;
  let details: Record<string, any> = {};
  
  try {
    const r = await fetch(`${BASE_URL}/v1/audio/speech`, {
      method: "POST",
      headers: H,
      body: JSON.stringify({
        model: model,
        input: text,
        voice: voice
      })
    });
    
    const contentType = r.headers.get("content-type") || "";
    success = r.ok;
    
    if (r.ok) {
      const buffer = await r.arrayBuffer();
      details = {
        contentType,
        sizeBytes: buffer.byteLength,
        sizeKB: Math.round(buffer.byteLength / 1024),
        inputChars: text.length
      };
    } else {
      const text = await r.text();
      error = text;
    }
  } catch (e: any) {
    error = e.message;
  }
  
  const responseTime = Date.now() - startTime;
  await sleep(500);
  const pollenAfter = await getBalance();
  
  return {
    category: "AUDIO_TTS",
    model,
    method: "POST /v1/audio/speech",
    endpoint: "/v1/audio/speech",
    success,
    pollenBefore,
    pollenAfter,
    pollenUsed: pollenBefore - pollenAfter,
    responseTime,
    details,
    error
  };
}

async function testSimpleTTS(text: string, voice: string = "alloy"): Promise<TestResult> {
  const pollenBefore = await getBalance();
  const startTime = Date.now();
  
  let success = false;
  let error: string | undefined;
  let details: Record<string, any> = {};
  
  try {
    const r = await fetch(`${BASE_URL}/audio/${encodeURIComponent(text)}?voice=${voice}`, {
      headers: H
    });
    
    const contentType = r.headers.get("content-type") || "";
    success = r.ok;
    
    if (r.ok) {
      const buffer = await r.arrayBuffer();
      details = {
        contentType,
        sizeBytes: buffer.byteLength,
        sizeKB: Math.round(buffer.byteLength / 1024),
        inputChars: text.length
      };
    } else {
      error = await r.text();
    }
  } catch (e: any) {
    error = e.message;
  }
  
  const responseTime = Date.now() - startTime;
  await sleep(500);
  const pollenAfter = await getBalance();
  
  return {
    category: "AUDIO_TTS",
    model: "elevenlabs",
    method: "GET /audio/{text}",
    endpoint: "/audio/{text}",
    success,
    pollenBefore,
    pollenAfter,
    pollenUsed: pollenBefore - pollenAfter,
    responseTime,
    details,
    error
  };
}

async function testVision(model: string, prompt: string, imageUrl: string): Promise<TestResult> {
  const pollenBefore = await getBalance();
  const startTime = Date.now();
  
  let success = false;
  let error: string | undefined;
  let details: Record<string, any> = {};
  
  try {
    const r = await fetch(`${BASE_URL}/v1/chat/completions`, {
      method: "POST",
      headers: H,
      body: JSON.stringify({
        model: model,
        messages: [{
          role: "user",
          content: [
            { type: "text", text: prompt },
            { type: "image_url", image_url: { url: imageUrl } }
          ]
        }],
        max_tokens: 200
      })
    });
    
    const data = await r.json();
    success = r.ok;
    
    if (r.ok) {
      details = {
        promptTokens: data.usage?.prompt_tokens,
        completionTokens: data.usage?.completion_tokens,
        totalTokens: data.usage?.total_tokens,
        responsePreview: data.choices?.[0]?.message?.content?.substring(0, 100)
      };
    } else {
      error = data.error?.message || JSON.stringify(data);
    }
  } catch (e: any) {
    error = e.message;
  }
  
  const responseTime = Date.now() - startTime;
  await sleep(500);
  const pollenAfter = await getBalance();
  
  return {
    category: "VISION",
    model,
    method: "POST /v1/chat/completions (vision)",
    endpoint: "/v1/chat/completions",
    success,
    pollenBefore,
    pollenAfter,
    pollenUsed: pollenBefore - pollenAfter,
    responseTime,
    details,
    error
  };
}

// ============================================================
// MAIN TEST RUNNER
// ============================================================

async function main() {
  console.log("=".repeat(80));
  console.log("POLLINATIONS AI - COST ESTIMATOR");
  console.log("=".repeat(80));
  
  // Check initial balance
  console.log("\n📊 Checking initial balance...");
  const initialBalance = await getBalance();
  console.log(`   Initial balance: ${initialBalance} pollen`);
  
  if (initialBalance <= 0) {
    console.log("❌ No pollen available for testing!");
    return;
  }
  
  // ============================================================
  // TEXT TESTS
  // ============================================================
  console.log("\n" + "=".repeat(80));
  console.log("TESTING TEXT GENERATION");
  console.log("=".repeat(80));
  
  // Test 1: OpenAI GPT-5 Mini
  console.log("\n📝 Test 1: OpenAI GPT-5 Mini (openai)");
  let result = await testTextGeneration("openai", "Say 'Hello World' in exactly 3 words.", 20);
  results.push(result);
  console.log(`   Status: ${result.success ? "✅" : "❌"} | Pollen: ${result.pollenUsed} | Time: ${result.responseTime}ms`);
  if (result.error) console.log(`   Error: ${result.error}`);
  if (result.details.completionTokens) {
    console.log(`   Tokens: ${result.details.promptTokens} prompt + ${result.details.completionTokens} completion`);
    console.log(`   Pollen/token: ${(result.pollenUsed / (result.details.promptTokens + result.details.completionTokens)).toFixed(6)}`);
  }
  
  await sleep(1000);
  
  // Test 2: Mistral
  console.log("\n📝 Test 2: Mistral Small 3.2 (mistral)");
  result = await testTextGeneration("mistral", "Count from 1 to 5.", 30);
  results.push(result);
  console.log(`   Status: ${result.success ? "✅" : "❌"} | Pollen: ${result.pollenUsed} | Time: ${result.responseTime}ms`);
  if (result.details.completionTokens) {
    console.log(`   Tokens: ${result.details.promptTokens} prompt + ${result.details.completionTokens} completion`);
    console.log(`   Pollen/token: ${(result.pollenUsed / (result.details.promptTokens + result.details.completionTokens)).toFixed(6)}`);
  }
  
  await sleep(1000);
  
  // Test 3: Simple text endpoint
  console.log("\n📝 Test 3: Simple text endpoint (openai-fast)");
  result = await testSimpleText("openai-fast", "Say hi");
  results.push(result);
  console.log(`   Status: ${result.success ? "✅" : "❌"} | Pollen: ${result.pollenUsed} | Time: ${result.responseTime}ms`);
  
  await sleep(1000);
  
  // ============================================================
  // IMAGE TESTS
  // ============================================================
  console.log("\n" + "=".repeat(80));
  console.log("TESTING IMAGE GENERATION");
  console.log("=".repeat(80));
  
  // Test 4: Flux Schnell (free model)
  console.log("\n🖼️ Test 4: Flux Schnell (flux) - 512x512");
  result = await testImageGeneration("flux", "a cute cat", 512, 512);
  results.push(result);
  console.log(`   Status: ${result.success ? "✅" : "❌"} | Pollen: ${result.pollenUsed} | Time: ${result.responseTime}ms`);
  if (result.details.sizeKB) {
    console.log(`   Image size: ${result.details.sizeKB} KB`);
  }
  
  await sleep(1000);
  
  // Test 5: Z-Image
  console.log("\n🖼️ Test 5: Z-Image Turbo (zimage) - 512x512");
  result = await testImageGeneration("zimage", "a red apple", 512, 512);
  results.push(result);
  console.log(`   Status: ${result.success ? "✅" : "❌"} | Pollen: ${result.pollenUsed} | Time: ${result.responseTime}ms`);
  
  await sleep(1000);
  
  // ============================================================
  // AUDIO TESTS
  // ============================================================
  console.log("\n" + "=".repeat(80));
  console.log("TESTING AUDIO GENERATION (TTS)");
  console.log("=".repeat(80));
  
  // Test 6: ElevenLabs TTS
  console.log("\n🔊 Test 6: ElevenLabs TTS (elevenlabs)");
  result = await testTTS("elevenlabs", "Hello, this is a test.", "alloy");
  results.push(result);
  console.log(`   Status: ${result.success ? "✅" : "❌"} | Pollen: ${result.pollenUsed} | Time: ${result.responseTime}ms`);
  if (result.details.sizeKB) {
    console.log(`   Audio size: ${result.details.sizeKB} KB | Input chars: ${result.details.inputChars}`);
    console.log(`   Pollen/char: ${(result.pollenUsed / result.details.inputChars).toFixed(6)}`);
  }
  
  await sleep(1000);
  
  // Test 7: Simple TTS endpoint
  console.log("\n🔊 Test 7: Simple TTS endpoint");
  result = await testSimpleTTS("Testing TTS", "nova");
  results.push(result);
  console.log(`   Status: ${result.success ? "✅" : "❌"} | Pollen: ${result.pollenUsed} | Time: ${result.responseTime}ms`);
  
  await sleep(1000);
  
  // ============================================================
  // VISION TEST
  // ============================================================
  console.log("\n" + "=".repeat(80));
  console.log("TESTING VISION (IMAGE INPUT)");
  console.log("=".repeat(80));
  
  // Test 8: Vision with OpenAI
  console.log("\n👁️ Test 8: Vision with OpenAI GPT-5 Mini");
  result = await testVision("openai", "Describe this image in one sentence.", "https://picsum.photos/200");
  results.push(result);
  console.log(`   Status: ${result.success ? "✅" : "❌"} | Pollen: ${result.pollenUsed} | Time: ${result.responseTime}ms`);
  if (result.details.completionTokens) {
    console.log(`   Tokens: ${result.details.promptTokens} prompt + ${result.details.completionTokens} completion`);
  }
  
  // ============================================================
  // FINAL BALANCE
  // ============================================================
  console.log("\n" + "=".repeat(80));
  console.log("FINAL RESULTS");
  console.log("=".repeat(80));
  
  const finalBalance = await getBalance();
  const totalUsed = initialBalance - finalBalance;
  
  console.log(`\n💰 Balance:`);
  console.log(`   Initial: ${initialBalance} pollen`);
  console.log(`   Final: ${finalBalance} pollen`);
  console.log(`   Total used: ${totalUsed} pollen`);
  
  // Summary table
  console.log("\n📊 Summary by category:\n");
  console.log("Category | Model | Method | Success | Pollen | Time");
  console.log("-".repeat(70));
  
  for (const r of results) {
    console.log(
      `${r.category.padEnd(12)} | ${r.model.padEnd(15)} | ${r.method.substring(0, 25).padEnd(25)} | ` +
      `${r.success ? "✅" : "❌"} | ${r.pollenUsed.toString().padStart(5)} | ${r.responseTime}ms`
    );
  }
  
  // Cost analysis
  console.log("\n📈 Cost Analysis:\n");
  
  const successfulResults = results.filter(r => r.success && r.pollenUsed > 0);
  
  for (const r of successfulResults) {
    if (r.category === "TEXT" && r.details.completionTokens) {
      const totalTokens = (r.details.promptTokens || 0) + (r.details.completionTokens || 0);
      const perToken = r.pollenUsed / totalTokens;
      console.log(`${r.model}: ${perToken.toFixed(6)} pollen/token (${(perToken * 1e6).toFixed(2)}/M tokens)`);
    }
    if (r.category === "IMAGE") {
      console.log(`${r.model}: ${r.pollenUsed} pollen/image`);
    }
    if (r.category === "AUDIO_TTS" && r.details.inputChars) {
      console.log(`${r.model}: ${(r.pollenUsed / r.details.inputChars).toFixed(6)} pollen/char`);
    }
  }
  
  // Save results
  const reportPath = "/home/z/my-project/download/cost_estimator_results.json";
  await Bun.write(reportPath, JSON.stringify({
    timestamp: new Date().toISOString(),
    initialBalance,
    finalBalance,
    totalUsed,
    results
  }, null, 2));
  
  console.log(`\n📁 Results saved to: ${reportPath}`);
}

main().catch(console.error);
