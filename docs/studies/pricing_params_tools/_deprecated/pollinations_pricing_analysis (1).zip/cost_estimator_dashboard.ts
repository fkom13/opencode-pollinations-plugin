#!/usr/bin/env bun
/**
 * pollinations_cost_dashboard.ts
 * 
 * Dashboard complet de comparaison coûts THÉORIQUES vs RÉELS
 * Avec estimateur de coût par type de requête
 */

const API_KEY = "sk_iUdeP1sX21yJjGfuH6fHBPQN1nk1Mf1q";
const BASE_URL = "https://gen.pollinations.ai";

const H: HeadersInit = {
  "Authorization": `Bearer ${API_KEY}`,
  "Content-Type": "application/json"
};

// ============================================================
// TYPES
// ============================================================

interface PricingData {
  name: string;
  description?: string;
  pricing?: {
    promptTextTokens?: number;
    completionTextTokens?: number;
    promptCachedTokens?: number;
    promptImageTokens?: number;
    completionImageTokens?: number;
    promptAudioTokens?: number;
    completionAudioTokens?: number;
    promptAudioSeconds?: number;
    completionAudioSeconds?: number;
    completionVideoSeconds?: number;
    completionVideoTokens?: number;
  };
  paid_only?: boolean;
  input_modalities?: string[];
  output_modalities?: string[];
  [k: string]: unknown;
}

interface TestResult {
  category: string;
  model: string;
  method: string;
  success: boolean;
  pollenUsed: number;
  inputTokens?: number;
  outputTokens?: number;
  inputChars?: number;
  imageSize?: number;
  duration?: number;
  theoreticalCost?: number;
  actualCost?: number;
  variance?: number;
}

// ============================================================
// API FUNCTIONS
// ============================================================

async function get<T>(url: string): Promise<T> {
  const r = await fetch(url, { headers: H });
  if (!r.ok) throw new Error(`HTTP ${r.status} on ${url}`);
  return r.json();
}

async function getBalance(): Promise<number> {
  const data = await get<{ balance: number }>(`${BASE_URL}/account/balance`);
  return data.balance;
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ============================================================
// TEST FUNCTIONS
// ============================================================

const results: TestResult[] = [];

async function testTextChat(model: string, prompt: string, maxTokens: number = 50): Promise<TestResult> {
  const pricingModels = await get<PricingData[]>(`${BASE_URL}/text/models`);
  const modelInfo = pricingModels.find(m => m.name === model);
  
  const pollenBefore = await getBalance();
  
  let success = false;
  let inputTokens = 0;
  let outputTokens = 0;
  let error: string | undefined;
  
  try {
    const r = await fetch(`${BASE_URL}/v1/chat/completions`, {
      method: "POST",
      headers: H,
      body: JSON.stringify({
        model,
        messages: [{ role: "user", content: prompt }],
        max_tokens: maxTokens
      })
    });
    
    const data = await r.json();
    success = r.ok;
    
    if (r.ok) {
      inputTokens = data.usage?.prompt_tokens || 0;
      outputTokens = data.usage?.completion_tokens || 0;
    } else {
      error = data.error?.message;
    }
  } catch (e: any) {
    error = e.message;
  }
  
  await sleep(300);
  const pollenAfter = await getBalance();
  const actualCost = pollenBefore - pollenAfter;
  
  // Calculate theoretical cost
  let theoreticalCost = 0;
  if (modelInfo?.pricing) {
    const ptt = modelInfo.pricing.promptTextTokens || 0;
    const ctt = modelInfo.pricing.completionTextTokens || 0;
    theoreticalCost = ptt * inputTokens + ctt * outputTokens;
  }
  
  return {
    category: "TEXT",
    model,
    method: "POST /v1/chat/completions",
    success,
    pollenUsed: actualCost,
    inputTokens,
    outputTokens,
    theoreticalCost,
    actualCost,
    variance: theoreticalCost > 0 ? ((actualCost - theoreticalCost) / theoreticalCost) * 100 : 0
  };
}

async function testImage(model: string, prompt: string, width: number = 512, height: number = 512): Promise<TestResult> {
  const imageModels = await get<PricingData[]>(`${BASE_URL}/image/models`);
  const modelInfo = imageModels.find(m => m.name === model);
  
  const pollenBefore = await getBalance();
  
  let success = false;
  let imageSize = 0;
  let error: string | undefined;
  
  try {
    const url = `${BASE_URL}/image/${encodeURIComponent(prompt)}?model=${model}&width=${width}&height=${height}`;
    const r = await fetch(url, { headers: H });
    
    success = r.ok;
    
    if (r.ok) {
      const buffer = await r.arrayBuffer();
      imageSize = buffer.byteLength;
    } else {
      error = await r.text();
    }
  } catch (e: any) {
    error = e.message;
  }
  
  await sleep(300);
  const pollenAfter = await getBalance();
  const actualCost = pollenBefore - pollenAfter;
  
  // Calculate theoretical cost
  let theoreticalCost = 0;
  if (modelInfo?.pricing) {
    // For flat-rate models
    if (modelInfo.pricing.completionImageTokens) {
      theoreticalCost = modelInfo.pricing.completionImageTokens;
    }
  }
  
  return {
    category: "IMAGE",
    model,
    method: "GET /image/{prompt}",
    success,
    pollenUsed: actualCost,
    imageSize,
    theoreticalCost,
    actualCost,
    variance: theoreticalCost > 0 ? ((actualCost - theoreticalCost) / theoreticalCost) * 100 : 0
  };
}

async function testTTS(model: string, text: string, voice: string = "alloy"): Promise<TestResult> {
  const audioModels = await get<PricingData[]>(`${BASE_URL}/audio/models`);
  const modelInfo = audioModels.find(m => m.name === model);
  
  const pollenBefore = await getBalance();
  
  let success = false;
  let error: string | undefined;
  
  try {
    const r = await fetch(`${BASE_URL}/v1/audio/speech`, {
      method: "POST",
      headers: H,
      body: JSON.stringify({ model, input: text, voice })
    });
    
    success = r.ok;
    if (!r.ok) error = await r.text();
  } catch (e: any) {
    error = e.message;
  }
  
  await sleep(300);
  const pollenAfter = await getBalance();
  const actualCost = pollenBefore - pollenAfter;
  
  // Calculate theoretical cost
  let theoreticalCost = 0;
  if (modelInfo?.pricing?.completionAudioTokens) {
    // 1 token ≈ 1 char for TTS
    theoreticalCost = modelInfo.pricing.completionAudioTokens * text.length;
  }
  
  return {
    category: "AUDIO_TTS",
    model,
    method: "POST /v1/audio/speech",
    success,
    pollenUsed: actualCost,
    inputChars: text.length,
    theoreticalCost,
    actualCost,
    variance: theoreticalCost > 0 ? ((actualCost - theoreticalCost) / theoreticalCost) * 100 : 0
  };
}

async function testVision(model: string, prompt: string, imageUrl: string): Promise<TestResult> {
  const pollenBefore = await getBalance();
  
  let success = false;
  let inputTokens = 0;
  let outputTokens = 0;
  
  try {
    const r = await fetch(`${BASE_URL}/v1/chat/completions`, {
      method: "POST",
      headers: H,
      body: JSON.stringify({
        model,
        messages: [{
          role: "user",
          content: [
            { type: "text", text: prompt },
            { type: "image_url", image_url: { url: imageUrl } }
          ]
        }],
        max_tokens: 100
      })
    });
    
    const data = await r.json();
    success = r.ok;
    if (r.ok) {
      inputTokens = data.usage?.prompt_tokens || 0;
      outputTokens = data.usage?.completion_tokens || 0;
    }
  } catch (e: any) {}
  
  await sleep(300);
  const pollenAfter = await getBalance();
  const actualCost = pollenBefore - pollenAfter;
  
  return {
    category: "VISION",
    model,
    method: "POST /v1/chat/completions (vision)",
    success,
    pollenUsed: actualCost,
    inputTokens,
    outputTokens,
    actualCost
  };
}

// ============================================================
// MAIN
// ============================================================

async function main() {
  console.log("=".repeat(90));
  console.log("📊 POLLINATIONS AI - COST ESTIMATOR DASHBOARD");
  console.log("=".repeat(90));
  
  // Get initial balance
  const initialBalance = await getBalance();
  console.log(`\n💰 Current Balance: ${initialBalance} pollen`);
  
  // Load all model data
  const [textModels, imageModels, audioModels] = await Promise.all([
    get<PricingData[]>(`${BASE_URL}/text/models`),
    get<PricingData[]>(`${BASE_URL}/image/models`),
    get<PricingData[]>(`${BASE_URL}/audio/models`)
  ]);
  
  // ============================================================
  // THEORETICAL PRICING TABLE
  // ============================================================
  console.log("\n" + "=".repeat(90));
  console.log("📈 THEORETICAL PRICING (from API)");
  console.log("=".repeat(90));
  
  console.log("\n📝 TEXT MODELS (per 1M tokens):\n");
  console.log("Model".padEnd(25) + "| Input(/M)".padStart(12) + "| Output(/M)".padStart(12) + "| Est. 500 tokens");
  console.log("-".repeat(70));
  
  for (const m of textModels.slice(0, 10)) {
    const ptt = (m.pricing?.promptTextTokens || 0) * 1e6;
    const ctt = (m.pricing?.completionTextTokens || 0) * 1e6;
    const estCost = ((m.pricing?.promptTextTokens || 0) * 200 + (m.pricing?.completionTextTokens || 0) * 300);
    console.log(
      `${m.name.padEnd(25)}| ${ptt.toFixed(2).padStart(10)}/M| ${ctt.toFixed(2).padStart(10)}/M| ${estCost.toFixed(6)} pollen`
    );
  }
  
  console.log("\n🖼️ IMAGE MODELS:\n");
  console.log("Model".padEnd(25) + "| Per Image".padStart(12) + "| Type");
  console.log("-".repeat(55));
  
  for (const m of imageModels.filter(m => !m.pricing?.completionVideoSeconds && !m.pricing?.completionVideoTokens).slice(0, 8)) {
    const cit = m.pricing?.completionImageTokens || 0;
    const type = m.pricing?.promptTextTokens ? "token-based" : "flat-rate";
    console.log(`${m.name.padEnd(25)}| ${cit.toFixed(6).padStart(10)}| ${type}`);
  }
  
  console.log("\n🔊 AUDIO MODELS:\n");
  console.log("Model".padEnd(25) + "| Per Char/Sec".padStart(15) + "| Type");
  console.log("-".repeat(55));
  
  for (const m of audioModels) {
    const cat = m.pricing?.completionAudioTokens || 0;
    const pas = m.pricing?.promptAudioSeconds || 0;
    const type = pas > 0 ? "STT (per sec)" : "TTS (per char)";
    const cost = pas > 0 ? pas : cat;
    console.log(`${m.name.padEnd(25)}| ${cost.toFixed(6).padStart(13)}| ${type}`);
  }
  
  // ============================================================
  // REAL TESTS
  // ============================================================
  console.log("\n\n" + "=".repeat(90));
  console.log("🧪 REAL API TESTS");
  console.log("=".repeat(90));
  
  // TEXT tests
  console.log("\n📝 Testing TEXT models...\n");
  
  const textTests = [
    { model: "openai", prompt: "Say 'hello' in 5 words", maxTokens: 20 },
    { model: "mistral", prompt: "Count 1 to 3", maxTokens: 20 },
    { model: "openai-fast", prompt: "Say hi", maxTokens: 10 },
    { model: "qwen-coder", prompt: "print('hi')", maxTokens: 20 },
  ];
  
  for (const test of textTests) {
    const result = await testTextChat(test.model, test.prompt, test.maxTokens);
    results.push(result);
    console.log(`   ${result.model}: ${result.success ? "✅" : "❌"} | ` +
      `Theoretical: ${result.theoreticalCost?.toFixed(6) || 'N/A'} | ` +
      `Actual: ${result.actualCost?.toFixed(6)} | ` +
      `Variance: ${result.variance?.toFixed(1) || 'N/A'}%`);
    await sleep(500);
  }
  
  // IMAGE tests
  console.log("\n🖼️ Testing IMAGE models...\n");
  
  const imageTests = [
    { model: "flux", prompt: "a red circle", w: 256, h: 256 },
    { model: "zimage", prompt: "a blue square", w: 256, h: 256 },
  ];
  
  for (const test of imageTests) {
    const result = await testImage(test.model, test.prompt, test.w, test.h);
    results.push(result);
    console.log(`   ${result.model}: ${result.success ? "✅" : "❌"} | ` +
      `Theoretical: ${result.theoreticalCost?.toFixed(6) || 'N/A'} | ` +
      `Actual: ${result.actualCost?.toFixed(6)} | ` +
      `Size: ${result.imageSize ? Math.round(result.imageSize/1024) + 'KB' : 'N/A'}`);
    await sleep(500);
  }
  
  // AUDIO tests
  console.log("\n🔊 Testing AUDIO models...\n");
  
  const audioTests = [
    { model: "elevenlabs", text: "Hello world", voice: "alloy" },
  ];
  
  for (const test of audioTests) {
    const result = await testTTS(test.model, test.text, test.voice);
    results.push(result);
    console.log(`   ${result.model}: ${result.success ? "✅" : "❌"} | ` +
      `Theoretical: ${result.theoreticalCost?.toFixed(6) || 'N/A'} | ` +
      `Actual: ${result.actualCost?.toFixed(6)} | ` +
      `Chars: ${result.inputChars}`);
    await sleep(500);
  }
  
  // VISION test
  console.log("\n👁️ Testing VISION...\n");
  
  const visionResult = await testVision("openai", "Describe in 5 words", "https://picsum.photos/100");
  results.push(visionResult);
  console.log(`   ${visionResult.model}: ${visionResult.success ? "✅" : "❌"} | ` +
    `Actual: ${visionResult.actualCost?.toFixed(6)} | ` +
    `Tokens: ${visionResult.inputTokens}+${visionResult.outputTokens}`);
  
  // ============================================================
  // COST ESTIMATOR TABLE
  // ============================================================
  console.log("\n\n" + "=".repeat(90));
  console.log("💰 COST ESTIMATOR - How much can you do with 1 pollen?");
  console.log("=".repeat(90));
  
  const finalBalance = await getBalance();
  const totalUsed = initialBalance - finalBalance;
  
  console.log(`\n   Balance used: ${totalUsed.toFixed(6)} pollen (${results.length} tests)`);
  
  console.log("\n┌────────────────────────────────────────────────────────────────────────────────────┐");
  console.log("│ ESTIMATED CAPACITY WITH 1 POLLEN                                                   │");
  console.log("├──────────────────┬──────────────────┬──────────────────┬──────────────────────────┤");
  console.log("│ Model            │ Type             │ Cost/Request     │ Requests per 1 pollen    │");
  console.log("├──────────────────┼──────────────────┼──────────────────┼──────────────────────────┤");
  
  // Calculate capacity based on actual tests
  const modelCosts: Record<string, { type: string; cost: number }> = {};
  
  for (const r of results.filter(r => r.success)) {
    if (r.category === "TEXT" && r.inputTokens && r.outputTokens) {
      // Estimate cost for a typical request (200 input + 300 output)
      const modelInfo = textModels.find(m => m.name === r.model);
      if (modelInfo?.pricing) {
        const estCost = (modelInfo.pricing.promptTextTokens || 0) * 200 + 
                       (modelInfo.pricing.completionTextTokens || 0) * 300;
        modelCosts[r.model] = { type: "TEXT", cost: estCost };
      }
    }
    if (r.category === "IMAGE" && r.actualCost && r.actualCost > 0) {
      modelCosts[r.model] = { type: "IMAGE", cost: r.actualCost };
    }
    if (r.category === "IMAGE" && r.theoreticalCost && r.theoreticalCost > 0) {
      if (!modelCosts[r.model]) {
        modelCosts[r.model] = { type: "IMAGE", cost: r.theoreticalCost };
      }
    }
    if (r.category === "AUDIO_TTS" && r.actualCost && r.inputChars) {
      // Cost per 100 chars (typical TTS request)
      const estCost = (r.actualCost / r.inputChars) * 100;
      modelCosts[r.model] = { type: "AUDIO_TTS", cost: estCost };
    }
  }
  
  // Add theoretical costs for models we couldn't test
  for (const m of textModels) {
    if (!modelCosts[m.name] && m.pricing?.promptTextTokens) {
      const estCost = (m.pricing.promptTextTokens || 0) * 200 + 
                     (m.pricing.completionTextTokens || 0) * 300;
      modelCosts[m.name] = { type: "TEXT", cost: estCost };
    }
  }
  
  for (const m of imageModels) {
    if (!modelCosts[m.name] && m.pricing?.completionImageTokens && !m.pricing?.completionVideoSeconds) {
      const cit = m.pricing.completionImageTokens;
      // For token-based, estimate ~1500 tokens per image
      const estCost = m.pricing.promptTextTokens ? cit * 1500 : cit;
      modelCosts[m.name] = { type: "IMAGE", cost: estCost };
    }
  }
  
  // Sort by cost
  const sortedCosts = Object.entries(modelCosts)
    .sort((a, b) => a[1].cost - b[1].cost);
  
  for (const [model, info] of sortedCosts.slice(0, 20)) {
    const requests = info.cost > 0 ? Math.round(1 / info.cost) : 0;
    const reqStr = requests >= 1000 ? `${Math.round(requests/100)/10}K` : requests.toString();
    console.log(`│ ${model.padEnd(16)} │ ${info.type.padEnd(16)} │ ${info.cost.toFixed(6).padStart(16)} │ ${reqStr.padStart(24)} │`);
  }
  
  console.log("└──────────────────┴──────────────────┴──────────────────┴──────────────────────────┘");
  
  // ============================================================
  // REQUEST TYPE COST BREAKDOWN
  // ============================================================
  console.log("\n\n" + "=".repeat(90));
  console.log("📊 COST BREAKDOWN BY REQUEST TYPE");
  console.log("=".repeat(90));
  
  console.log(`
┌─────────────────────────────────────────────────────────────────────────────────────┐
│ TEXT GENERATION                                                                     │
├─────────────────────────────────────────────────────────────────────────────────────┤
│ • Prompt text tokens (input)  → Charged at model-specific rate                      │
│ • Completion text tokens (out)→ Charged at model-specific rate (usually 2-5x input) │
│ • Cached tokens               → Lower rate for repeated prompts                     │
│ • Audio tokens                → Higher rate for audio input/output                  │
│                                                                                     │
│ Typical request (200 input + 300 output tokens):                                    │
│   • Cheapest (nova-fast):    ~0.00004 pollen                                        │
│   • Standard (mistral):      ~0.00011 pollen                                        │
│   • Premium (claude-large):  ~0.0135 pollen                                         │
├─────────────────────────────────────────────────────────────────────────────────────┤
│ IMAGE GENERATION                                                                    │
├─────────────────────────────────────────────────────────────────────────────────────┤
│ • Flat-rate models (flux, zimage): Fixed cost per image regardless of size         │
│ • Token-based (gptimage, nanobanana): Cost varies with resolution/complexity        │
│                                                                                     │
│ Typical request:                                                                    │
│   • Flux Schnell:     0.0002 pollen/image (any size)                               │
│   • Z-Image Turbo:    0.0002 pollen/image (any size)                               │
│   • GPT Image Mini:   ~0.008-0.013 pollen/image (depends on resolution)            │
├─────────────────────────────────────────────────────────────────────────────────────┤
│ AUDIO - TEXT TO SPEECH (TTS)                                                        │
├─────────────────────────────────────────────────────────────────────────────────────┤
│ • Cost per character generated                                                      │
│                                                                                     │
│ Typical request (100 characters):                                                   │
│   • ElevenLabs v3:  ~0.018 pollen                                                   │
│   • ~55 requests per pollen                                                         │
├─────────────────────────────────────────────────────────────────────────────────────┤
│ AUDIO - SPEECH TO TEXT (STT)                                                        │
├─────────────────────────────────────────────────────────────────────────────────────┤
│ • Cost per second of audio transcribed                                              │
│                                                                                     │
│ Typical request (60 seconds):                                                       │
│   • Whisper:     ~0.0027 pollen                                                     │
│   • Scribe:      ~0.0067 pollen                                                     │
├─────────────────────────────────────────────────────────────────────────────────────┤
│ VIDEO GENERATION                                                                    │
├─────────────────────────────────────────────────────────────────────────────────────┤
│ • Cost per second of video generated                                                │
│                                                                                     │
│ Typical request (5 seconds):                                                        │
│   • Grok Video:  ~0.0125 pollen                                                     │
│   • Veo:         ~0.75 pollen                                                       │
│   • Seedance:    ~0.005-0.009 pollen                                                │
├─────────────────────────────────────────────────────────────────────────────────────┤
│ VISION (IMAGE INPUT)                                                                │
├─────────────────────────────────────────────────────────────────────────────────────┤
│ • Image tokens + text tokens                                                        │
│ • Image tokens cost more than text tokens                                           │
│                                                                                     │
│ Typical request:                                                                    │
│   • ~2-5x the cost of text-only for same output                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
`);
  
  // ============================================================
  // SAVE REPORT
  // ============================================================
  const report = {
    timestamp: new Date().toISOString(),
    balance: {
      initial: initialBalance,
      final: finalBalance,
      used: totalUsed
    },
    tests: results,
    modelCosts: Object.fromEntries(
      Object.entries(modelCosts).map(([k, v]) => [k, { ...v, requestsPerPollen: v.cost > 0 ? Math.round(1/v.cost) : 0 }])
    )
  };
  
  await Bun.write("/home/z/my-project/download/cost_estimator_dashboard.json", JSON.stringify(report, null, 2));
  
  console.log("\n📁 Report saved to: /home/z/my-project/download/cost_estimator_dashboard.json");
}

main().catch(console.error);
