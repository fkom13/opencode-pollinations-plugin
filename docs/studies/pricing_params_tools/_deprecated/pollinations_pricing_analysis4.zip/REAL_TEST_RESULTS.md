# 📊 RÉSULTATS DES TESTS RÉELS - POLLINATIONS AI

## Solde
- **Initial:** 2.75 pollen
- **Final:** 1.93 pollen  
- **Utilisé:** 0.82 pollen

---

## TEXT MODELS (Coût par million de tokens)

| Model | Cost (pollen) | Tokens | Cost/M tokens |
|-------|---------------|--------|---------------|
| qwen-safety | 0.00000304 | 304 | **0.01** |
| qwen-coder | 0.0000053 | 75 | **0.07** |
| nova-fast | 0.00000952 | 257 | **0.04** |
| openai-fast | 0.00001714 | 254 | **0.07** |
| mistral | 0.0000275 | 265 | **0.10** |
| gemini-fast | 0.0000275 | 260 | **0.11** |
| openai | 0.00004035 | 254 | **0.16** |
| kimi | 0.0000433 | 11 | ~3.94 |
| minimax | 0.0000441 | 6 | ~7.35 |
| glm | 0.0001064 | 68 | **1.56** |
| deepseek | 0.0001484 | 254 | **0.58** |

---

## IMAGE MODELS (Coût par image)

| Model | Cost (pollen) | Size | Notes |
|-------|---------------|------|-------|
| flux | **0.0002** | 2KB | ✅ Le moins cher |
| zimage | **0.0002** | 3KB | ✅ Le moins cher |
| klein | **0.008** | 3KB | |
| gptimage | **0.00852** | 45KB | Token-based (1065 tokens) |
| klein-large | **0.012** | 6KB | |

---

## VIDEO MODELS (Coût par vidéo)

| Model | Cost (pollen) | Duration | Size | Cost/sec |
|-------|---------------|----------|------|----------|
| seedance | **0.0357** | ~2s | 1MB | **0.018** |

**Notes:** 
- grok-video et wan n'ont pas généré de vidéo valide (fichier 850 bytes = erreur)
- seedance fonctionne bien

---

## AUDIO MODELS

### TTS (Text-to-Speech) - Coût par caractère

| Model | Cost (pollen) | Chars | Cost/char |
|-------|---------------|-------|-----------|
| elevenlabs | **0.00198** | 11 | **0.00018** |

### MUSIC - Coût par génération

| Model | Cost (pollen) | Duration | Size |
|-------|---------------|----------|------|
| elevenmusic | **0.75** | ~30s | 2.4MB |

---

## NON TESTÉS (nécéssitent fichiers ou erreurs)

### TEXT restants:
- openai-large, openai-audio, gemini-search, chickytutor, midijourney, claude-fast, perplexity-fast, perplexity-reasoning, qwen-character

### IMAGE restants:
- imagen-4 (erreur API)

### VIDEO restants:
- grok-video (erreur - pas de vidéo générée)
- wan (erreur - pas de vidéo générée)

### AUDIO restants:
- whisper (STT - nécessite fichier audio)
- scribe (STT - nécessite fichier audio)

---

## FORMULES DÉDUITES

```
TEXT:  cost = tokens × rate/M ÷ 1,000,000
IMAGE: cost = flat_rate (ne dépend pas de la taille)
VIDEO: cost = duration × rate/sec
AUDIO: cost = characters × rate/char
```

---

## AVEC 1 POLLEN VOUS POUVEZ:

| Catégorie | Modèle | Quantité |
|-----------|--------|----------|
| TEXT | qwen-safety | **100M tokens** (~200K requêtes) |
| TEXT | nova-fast | **25M tokens** (~50K requêtes) |
| TEXT | openai | **6M tokens** (~12K requêtes) |
| IMAGE | flux/zimage | **5,000 images** |
| IMAGE | klein | **125 images** |
| VIDEO | seedance | **56 secondes** (~28 vidéos de 2s) |
| AUDIO | elevenlabs | **5,555 caractères** |
| MUSIC | elevenmusic | **1.3 chansons** |

---

## LÉGENDE

✅ = Testé avec succès  
❌ = Erreur lors du test  
⏳ = Nécessite fichier upload (STT)
