#!/usr/bin/env bun
/**
 * Test API Pollinations - Récupération des données brutes
 * Usage: bun run test-api.ts
 */

const API_KEY = "sk_iUdeP1sX21yJjGfuH6fHBPQN1nk1Mf1q";
const H: HeadersInit = { Authorization: `Bearer ${API_KEY}` };

async function get<T>(url: string): Promise<T> {
  console.log(`Fetching: ${url}`);
  const r = await fetch(url, { headers: H });
  if (!r.ok) throw new Error(`HTTP ${r.status} on ${url}`);
  return r.json();
}

interface TextModel {
  name: string;
  description: string;
  pricing?: Record<string, unknown>;
  input_modalities?: string[];
  output_modalities?: string[];
  tools?: boolean;
  reasoning?: boolean;
  paid_only?: boolean;
  voices?: string[];
  context_window?: number;
  is_specialized?: boolean;
}

interface MediaModel {
  name: string;
  description?: string;
  paid_only?: boolean;
  voices?: string[];
  pricing?: Record<string, unknown>;
  [k: string]: unknown;
}

// Fetch all endpoints
console.log("=== Récupération des données API ===\n");

const [textModels, imageModels, audioModels] = await Promise.all([
  get<TextModel[]>("https://gen.pollinations.ai/text/models"),
  get<MediaModel[]>("https://gen.pollinations.ai/image/models"),
  get<MediaModel[]>("https://gen.pollinations.ai/audio/models"),
]);

console.log(`Text models: ${textModels.length}`);
console.log(`Image models: ${imageModels.length}`);
console.log(`Audio models: ${audioModels.length}`);

// Save raw data
const rawData = {
  timestamp: new Date().toISOString(),
  text: textModels,
  image: imageModels,
  audio: audioModels
};

await Bun.write("/home/z/my-project/download/raw-api-data.json", JSON.stringify(rawData, null, 2));
console.log("\nDonnées brutes sauvegardées dans raw-api-data.json");

// === Analyse détaillée des modèles TEXT ===
console.log("\n\n=== ANALYSE TEXT MODELS ===\n");

for (const m of textModels.slice(0, 5)) {
  console.log(`--- ${m.name} ---`);
  console.log(`Description: ${m.description}`);
  console.log(`Pricing: ${JSON.stringify(m.pricing, null, 2)}`);
  console.log(`Paid only: ${m.paid_only}`);
  console.log(`Input modalities: ${m.input_modalities}`);
  console.log(`Output modalities: ${m.output_modalities}`);
  console.log(`Reasoning: ${m.reasoning}`);
  console.log("");
}

// === Analyse détaillée des modèles IMAGE ===
console.log("\n\n=== ANALYSE IMAGE/VIDEO MODELS ===\n");

for (const m of imageModels.slice(0, 5)) {
  console.log(`--- ${m.name} ---`);
  console.log(`Description: ${m.description}`);
  console.log(`Pricing: ${JSON.stringify(m.pricing, null, 2)}`);
  console.log(`Paid only: ${m.paid_only}`);
  console.log("");
}

// === Analyse détaillée des modèles AUDIO ===
console.log("\n\n=== ANALYSE AUDIO MODELS ===\n");

for (const m of audioModels) {
  console.log(`--- ${m.name} ---`);
  console.log(`Description: ${m.description}`);
  console.log(`Pricing: ${JSON.stringify(m.pricing, null, 2)}`);
  console.log(`Paid only: ${m.paid_only}`);
  console.log("");
}

// === Calcul du coût estimé par modèle TEXT ===
console.log("\n\n=== CALCUL COÛT TEXT (formule actuelle) ===");
console.log("Formule: (promptTextTokens * 200 + completionTextTokens * 500) = coût par requête");
console.log("1 pollen = 1 / coût requêtes\n");

function n(v: unknown): number | null {
  const x = Number(v);
  return v === undefined || v === null || isNaN(x) || x === 0 ? null : x;
}

function per1pollen(cost: number | null): string {
  if (!cost || cost <= 0) return "—";
  const x = 1 / cost;
  if (x >= 10000)  return `${Math.round(x/1000)}K`;
  if (x >= 1000)   return `${Math.round(x/100)*100}`.replace(/(\d)(?=(\d{3})+$)/g, "$1,");
  if (x >= 100)    return `${Math.round(x)}`;
  if (x >= 10)     return `${Math.round(x)}`;
  return `${x.toFixed(1)}`;
}

for (const m of textModels.slice(0, 10)) {
  const pr = m.pricing ?? {};
  const pTokens = n(pr.promptTextTokens);
  const cTokens = n(pr.completionTextTokens);
  
  const reqCost = (pTokens ?? 0) * 200 + (cTokens ?? 0) * 500;
  console.log(`${m.name}: input=${pTokens}/token, output=${cTokens}/token, coût/requête=${reqCost}, 1pollen≈${per1pollen(reqCost)}`);
}

console.log("\n=== TERMINÉ ===");
