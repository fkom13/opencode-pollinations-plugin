#!/usr/bin/env bun
/**
 * Analyse approfondie des modèles TEXT
 * Objectif: Trouver la formule EXACTE utilisée dans le dashboard
 */

// Dashboard reference values
const dashboardText = [
  { name: "qwen-safety", responses: 200000 },
  { name: "qwen-character", responses: 33300 },
  { name: "nova-fast", responses: 20800 },
  { name: "mistral", responses: 4000 },
  { name: "gemini-search", responses: 4900 },
  { name: "gemini-fast", responses: 3300 },
  { name: "qwen-coder", responses: 1100 },
  { name: "grok", responses: 1200 },
  { name: "perplexity-fast", responses: 850 },
  { name: "openai", responses: 700 },
  { name: "openai-fast", responses: 700 },
  { name: "deepseek", responses: 250 },
  { name: "minimax", responses: 250 },
  { name: "perplexity-reasoning", responses: 200 },
  { name: "openai-audio", responses: 150 },
  { name: "midijourney", responses: 150 },
  { name: "chickytutor", responses: 100 },
  { name: "claude-fast", responses: 100 },
  { name: "kimi", responses: 100 },
  { name: "openai-large", responses: 95 },
  { name: "gemini", responses: 95 },
  { name: "glm", responses: 75 },
  { name: "claude", responses: 15 },
  { name: "claude-large", responses: 7 },
];

// Load API data
const rawData = await Bun.file("/home/z/my-project/download/raw-api-data.json").json();
const textModels = rawData.text;

function n(v: unknown): number | null {
  const x = Number(v);
  return v === undefined || v === null || isNaN(x) || x === 0 ? null : x;
}

console.log("=".repeat(80));
console.log("REVERSE ENGINEERING - FORMULE TEXT");
console.log("=".repeat(80));

// Calculate implied token counts for each model
console.log("\nCalcul des tokens IMPLICITES par le dashboard:\n");
console.log("Modèle | Dashboard | ptt(/M) | ctt(/M) | coût_cible | X_si_Y500 | Y_si_X200");
console.log("-".repeat(90));

const results: { name: string; ptt: number; ctt: number; targetCost: number; responses: number }[] = [];

for (const ref of dashboardText) {
  const apiModel = textModels.find((m: any) => m.name === ref.name);
  if (!apiModel) continue;
  
  const ptt = n(apiModel.pricing?.promptTextTokens) || 0;
  const ctt = n(apiModel.pricing?.completionTextTokens) || 0;
  const targetCost = 1 / ref.responses;
  
  results.push({ name: ref.name, ptt, ctt, targetCost, responses: ref.responses });
  
  // Solve: targetCost = ptt * X + ctt * Y
  // Try with Y = 500: X = (targetCost - ctt * 500) / ptt
  const X_if_Y500 = ptt > 0 ? (targetCost - ctt * 500) / ptt : null;
  // Try with X = 200: Y = (targetCost - ptt * 200) / ctt
  const Y_if_X200 = ctt > 0 ? (targetCost - ptt * 200) / ctt : null;
  
  const pttPerM = ptt * 1e6;
  const cttPerM = ctt * 1e6;
  
  console.log(
    `${ref.name.padEnd(20)} | ${ref.responses.toString().padStart(7)} | ` +
    `${pttPerM.toFixed(2).padStart(6)} | ${cttPerM.toFixed(2).padStart(6)} | ` +
    `${targetCost.toExponential(2).padStart(10)} | ` +
    `${X_if_Y500?.toFixed(0).padStart(8) || 'N/A'} | ` +
    `${Y_if_X200?.toFixed(0).padStart(8) || 'N/A'}`
  );
}

// Analyse statistique pour trouver la paire (X, Y) optimale
console.log("\n\n" + "=".repeat(80));
console.log("RECHERCHE DE LA PAIRE (INPUT_TOKENS, OUTPUT_TOKENS) OPTIMALE");
console.log("=".repeat(80));

// Grid search sur X (input) et Y (output)
const X_range = [50, 100, 150, 200, 250, 300, 350, 400, 500, 600, 700, 800, 1000];
const Y_range = [200, 250, 300, 333, 350, 400, 450, 500, 550, 600, 700, 800, 1000];

let bestError = Infinity;
let bestX = 0;
let bestY = 0;

console.log("\nRecherche par grid search...\n");

for (const X of X_range) {
  for (const Y of Y_range) {
    let totalError = 0;
    let validCount = 0;
    
    for (const r of results) {
      if (r.ptt === 0 || r.ctt === 0) continue;
      
      const calculatedCost = r.ptt * X + r.ctt * Y;
      const calculatedResponses = 1 / calculatedCost;
      const error = Math.abs(calculatedResponses - r.responses) / r.responses;
      
      totalError += error;
      validCount++;
    }
    
    const avgError = totalError / validCount;
    
    if (avgError < bestError) {
      bestError = avgError;
      bestX = X;
      bestY = Y;
    }
  }
}

console.log(`Meilleure paire trouvée: INPUT=${bestX}, OUTPUT=${bestY}`);
console.log(`Erreur moyenne: ${(bestError * 100).toFixed(2)}%`);

// Vérifions avec cette paire
console.log("\n\nVérification avec INPUT=" + bestX + ", OUTPUT=" + bestY + ":\n");
console.log("Modèle | Dashboard | Calculé | Erreur%");
console.log("-".repeat(50));

for (const r of results) {
  if (r.ptt === 0 || r.ctt === 0) continue;
  
  const calculatedCost = r.ptt * bestX + r.ctt * bestY;
  const calculatedResponses = Math.round(1 / calculatedCost);
  const error = Math.abs(calculatedResponses - r.responses) / r.responses * 100;
  
  console.log(
    `${r.name.padEnd(20)} | ${r.responses.toString().padStart(7)} | ` +
    `${calculatedResponses.toString().padStart(7)} | ${error.toFixed(1)}%`
  );
}

// Essai d'autres approches
console.log("\n\n" + "=".repeat(80));
console.log("AUTRES APPROCHES");
console.log("=".repeat(80));

// Approche 1: Uniquement basé sur output tokens
console.log("\n--- Approche: Basé uniquement sur OUTPUT tokens ---");
for (const outputTokens of [300, 333, 400, 450, 500, 550, 600]) {
  let totalError = 0;
  let validCount = 0;
  
  for (const r of results) {
    if (r.ctt === 0) continue;
    
    const calculatedCost = r.ctt * outputTokens;
    const calculatedResponses = 1 / calculatedCost;
    const error = Math.abs(calculatedResponses - r.responses) / r.responses;
    
    totalError += error;
    validCount++;
  }
  
  const avgError = totalError / validCount * 100;
  console.log(`Output=${outputTokens}: erreur moyenne = ${avgError.toFixed(1)}%`);
}

// Approche 2: Proportionnelle à la moyenne (ptt + ctt)/2
console.log("\n--- Approche: Moyenne (ptt + ctt)/2 multipliée par un facteur ---");
for (const factor of [250, 300, 350, 400, 450, 500, 550, 600, 700]) {
  let totalError = 0;
  let validCount = 0;
  
  for (const r of results) {
    if (r.ptt === 0 || r.ctt === 0) continue;
    
    const avgPrice = (r.ptt + r.ctt) / 2;
    const calculatedCost = avgPrice * factor;
    const calculatedResponses = 1 / calculatedCost;
    const error = Math.abs(calculatedResponses - r.responses) / r.responses;
    
    totalError += error;
    validCount++;
  }
  
  const avgError = totalError / validCount * 100;
  console.log(`Factor=${factor}: erreur moyenne = ${avgError.toFixed(1)}%`);
}

// Approche 3: Utiliser un ratio input/output spécifique
console.log("\n--- Approche: Ratio input/output = 1/2.5 (200 input, 500 output) ---");
let totalError = 0;
let validCount = 0;
for (const r of results) {
  if (r.ptt === 0 || r.ctt === 0) continue;
  
  const calculatedCost = r.ptt * 200 + r.ctt * 500;
  const calculatedResponses = 1 / calculatedCost;
  const error = Math.abs(calculatedResponses - r.responses) / r.responses;
  totalError += error;
  validCount++;
}
console.log(`Erreur moyenne: ${(totalError / validCount * 100).toFixed(1)}%`);

// Essayer de comprendre les cas particuliers
console.log("\n\n" + "=".repeat(80));
console.log("ANALYSE DES CAS PARTICULIERS");
console.log("=".repeat(80));

// Certains modèles semblent avoir des calculs très différents
const outliers = results.filter(r => {
  const calculatedCost = r.ptt * bestX + r.ctt * bestY;
  const calculatedResponses = 1 / calculatedCost;
  const error = Math.abs(calculatedResponses - r.responses) / r.responses;
  return error > 0.5; // Plus de 50% d'erreur
});

console.log("\nModèles avec erreur > 50%:");
for (const r of outliers) {
  const calculatedCost = r.ptt * bestX + r.ctt * bestY;
  const calculatedResponses = Math.round(1 / calculatedCost);
  const ratio = r.responses / calculatedResponses;
  
  console.log(`  ${r.name}: dashboard=${r.responses}, calculé=${calculatedResponses}, ratio=${ratio.toFixed(2)}x`);
}

// Conclusions
console.log("\n\n" + "=".repeat(80));
console.log("CONCLUSIONS");
console.log("=".repeat(80));
console.log(`
La formule exacte semble être:
  responses/pollen = 1 / (ptt × INPUT + ctt × OUTPUT)

Avec les paramètres optimaux trouvés:
  INPUT = ${bestX} tokens
  OUTPUT = ${bestY} tokens
  
Erreur moyenne: ${(bestError * 100).toFixed(1)}%

Cependant, certains modèles ont des erreurs significatives,
suggérant que le dashboard utilise peut-être:
1. Des valeurs INPUT/OUTPUT différentes selon le type de modèle
2. Une autre formule pour certains cas particuliers
3. Des valeurs manuelles ou des ajustements
`);
